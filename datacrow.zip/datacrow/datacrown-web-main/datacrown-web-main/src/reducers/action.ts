export const LOADING = 'REQUEST_LOADING';
export const CLOSE_ALERT = 'CLOSE_ALERT';
export const SUCCESS = 'REQUEST_SUCCESS';
export const FAILED = 'REQUEST_FAILED';
export const ERROR = 'REQUEST_ERROR';
export const VALIDATE = 'FORM_VALIDATION';
export const RESET_DEFAULT = 'RESET_DEFAULT';
    