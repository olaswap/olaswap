import Page from ".";

export default function page() {
  return <Page />;
}
