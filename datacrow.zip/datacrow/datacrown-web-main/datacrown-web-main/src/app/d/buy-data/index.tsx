"use client";
import React from "react";
import Layout from "@/layout";
import { Icon } from "@iconify/react";
import { StyledSubscription } from "./style";
import useModal from "@/hooks/useModal";
import BuySubscription from "@/components/subscriptions/buyData";
import FetchHandler from "@/components/utility/FetchHandler";
import { useDataPlansQuery } from "@/store/user";
import Image from "next/image";
import { IMAGES } from "@/constant";
import { useDispatch } from "react-redux";
import { handleSelectedDataPlan } from "@/store/component";
import util from "@/helpers/utils";

export interface IDataPlan {
  amount: number;
  validity: string;
  plan: string;
  id: number | null;
  network: string;
}

export default function BuyData() {
  const { visible, handleCancel, showModal } = useModal();

  const dispatch = useDispatch();
  const handleClick = (item: IDataPlan) => {
    dispatch(handleSelectedDataPlan(item));
    showModal();
  };

  const { isLoading, error, isError, isSuccess, data } =
    useDataPlansQuery(null);

  return (
    <Layout>
      <FetchHandler isLoading={isLoading} error={error} isError={isError} />
      {isSuccess && (
        <StyledSubscription>
          <section className="service-section">
            <div className="header">
              <div>
                <h5>Buy Data</h5>
                <p>Amazing data plans</p>
              </div>
              <Icon icon="mdi-light:wifi" />
            </div>


            <div className="row">
              <div className="col-md-6">
                <div className="provider mtn">MTN</div>

                {data.data.mtn.map((item: IDataPlan, idx: number) => (
                  <div
                    className="item"
                    key={idx}
                    role="button"
                    onClick={() => handleClick(item)}
                  >
                    <div>
                      <span>₦{util.numberFormat(item.amount, 2)}</span>
                      <span>
                        {item.plan}-{item.validity}
                      </span>
                    </div>
                    

                    <Image
                      src={IMAGES.mtn}
                      alt="mtn logo"
                      width={30}
                      height={30}
                    />
                  </div>
                ))}
              </div>

              <div className="col-md-6">
                <div className="provider airtel">Airtel</div>
                {data.data.airtel.map((item: IDataPlan, idx: number) => (
                  <div
                    className="item"
                    key={idx}
                    role="button"
                    onClick={() => handleClick(item)}
                  >
                    <div>
                      <span>₦{util.numberFormat(item.amount, 2)}</span>
                      <span>
                        {item.plan}-{item.validity}
                      </span>
                    </div>

                    <Image
                      src={IMAGES.airtel}
                      alt="airtel logo"
                      width={30}
                      height={30}
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="provider glo">Glo</div>

                {data.data.glo.map((item: IDataPlan, idx: number) => (
                  <div
                    className="item"
                    key={idx}
                    role="button"
                    onClick={() => handleClick(item)}
                  >
                    <div>
                      <span>₦{util.numberFormat(item.amount, 2)}</span>
                      <span>
                        {item.plan}-{item.validity}
                      </span>
                    </div>

                    <Image
                      src={IMAGES.glo}
                      alt="glo logo"
                      width={30}
                      height={30}
                    />
                  </div>
                ))}
              </div>

              <div className="col-md-6">
                <div className="provider nmobile">9mobile</div>
                {data.data["9mobile"].map((item: IDataPlan, idx: number) => (
                  <div
                    className="item"
                    key={idx}
                    role="button"
                    onClick={() => handleClick(item)}
                  >
                    <div>
                      <span>₦{util.numberFormat(item.amount, 2)}</span>
                      <span>
                        {item.plan}-{item.validity}
                      </span>
                    </div>

                    <Image
                      src={IMAGES.nMobile}
                      alt="9Mobile logo"
                      width={30}
                      height={30}
                    />
                  </div>
                ))}
              </div>
            </div>
          </section>
        </StyledSubscription>
      )}
      <BuySubscription visible={visible} handleCancel={handleCancel} />
    </Layout>
  );
}
