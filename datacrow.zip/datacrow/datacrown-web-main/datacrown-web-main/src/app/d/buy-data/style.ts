import styled from "styled-components";

export const StyledSubscription = styled.section`
  margin-top: 100px;
  .service-section {
    @media (max-width: 768px) {
      margin-top: 50px;
    }

    .header {
      background: linear-gradient(159.83deg, #0139cc -29.44%, #011d66 135.48%);
      border-radius: 20px;

      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 30px 30px;
      margin-bottom: 30px;
      border-radius: 10px;

      @media (max-width: 768px) {
        padding: 20px;
      }

      h5 {
        font-size: 20px;
        font-weight: 600;
        color: var(--white-color);
      }

      p {
        font-size: 15px;
        color: var(--white-color);
        margin: 0;
      }

      svg {
        font-size: 70px;
        color: var(--white-color);
        background-color: var(--primary-color);
        padding: 10px;
        border-radius: 100px;
      }
    }

    .provider {
      background-color: var(--primary-color);
      color: var(--white-color);
      padding: 10px 0;
      text-align: center;
      font-size: 20px;
      font-weight: 600;
      margin-top: 20px;
      margin-bottom: 40px;
      @media (max-width: 768px) {
        margin-top: 20px;
        margin-bottom: 30px;
      }

      &.mtn {
        @media (max-width: 768px) {
          margin-top: 0;
        }
      }

      img {
        margin-right: 20px;
      }
    }

    .item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: var(--white-color);
      padding: 15px 20px;
      margin-bottom: 20px;
      
      div {
        display: flex;
        flex-direction: column;

        font-weight: 500;
        font-size: 15px;

        @media (max-width: 768px) {
          text-align: left;
          font-size: 14px;
        }

        span:first-child {
          font-weight: 600;
        }

        span:last-child {
          font-size: 12px;
        }
      }

      img {
        @media (max-width: 768px) {
          width: 20px;
          height: 20px;
        }
      }
    }

    .item:hover {
      border-bottom: 1px solid var(--primary-color);
    }

    .row:last-child {
      margin-top: 0;
    }
  }
`;
