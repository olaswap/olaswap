import styled from "styled-components";

export const StyledTransactions = styled.div`
  margin-top: 100px;
  h3 {
    font-weight: 600;
    color: var(--black-color);
    margin-bottom: 5px;
    margin-top: 0;
    margin-bottom: 30px;
    font-size: 20px;
  }
  .item {
    background-color: var(--white-color);
    padding: 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    color: var(--black-color);

    div {
      display: flex;
      align-items: center;

      img {
        width: 30px;
        height: 30px;
        margin-right: 10px;
      }
    }
    p {
      font-size: 15px;
      display: flex;
      align-items: center;
      font-size: 13px;
      margin: 0;
      font-weight: 600;
      span {
        margin-right: 10px;
      }

      @media (max-width: 768px) {
        font-size: 12px;
      }
    }
  }
`;
