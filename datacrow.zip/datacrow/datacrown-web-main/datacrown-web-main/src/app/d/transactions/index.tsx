"use client";

import React from "react";
import Layout from "@/layout";
import { StyledTransactions } from "./style";
import { IMAGES } from "@/constant";
import Image from "next/image";
import { useTransactionsQuery } from "@/store/user";
import FetchHandler from "@/components/utility/FetchHandler";
import util from "@/helpers/utils";
import misc from "@/helpers/misc";

export default function Transactions() {
  const { isLoading, error, isError, isSuccess, data } =
    useTransactionsQuery(null);

  return (
    <Layout>
      <FetchHandler isLoading={isLoading} error={error} isError={isError} />
      {isSuccess && (
        <StyledTransactions>
          <h3>Transactions</h3>
          {data.data.map((item: any, idx: number) =>
            item.transactionType === "credit" ? (
              <div className="item" key={idx}>
                <div>
                  <Image src={IMAGES.bankIcon} alt="Glo" />
                  <p>
                    ₦{util.numberFormat(item.data.amount, 2)}{" "}
                    <span>Deposit</span>
                  </p>
                </div>
                <p>{util.formatDate(item.createdAt)}</p>
              </div>
            ) : (
              <div className="item" key={idx}>
                <div>
                  <Image
                    src={misc.findNetworkImage(item.data.provider)}
                    alt={item.data.provider}
                  />
                  <p>
                    <span>₦{item.amount}</span>{" "}
                    {item.data?.amount && item.data?.amount}
                  </p>
                </div>
                <p>
                  {util.formatDate(item.createdAt)}{" "}
                  {util.formatTime(item.createdAt)}
                </p>
              </div>
            )
          )}
        </StyledTransactions>
      )}
    </Layout>
  );
}
