"use client";

import Login from "./Login";
import Register from "./Register";
import ForgotPassword from "./ForgotPassword";
import { useDispatch, useSelector } from "react-redux";
import { handleAuthTab, selectAuthTab } from "@/store/component";

import { StyledAuthContainer } from "./style";
import Image from "next/image";
import { IMAGES } from "@/constant";

export default function Authentication() {
  const currentTab = useSelector(selectAuthTab);
  const dispatch = useDispatch();
  const handleTab = (type: string) => dispatch(handleAuthTab(type));

  return (
    <StyledAuthContainer>
      <div className="authentication-container">
        <div className="text-center">
          <Image
            src={IMAGES.logo}
            alt="App Logo"
            width={70}
            height={55}
            className="logo"
            onClick={() => handleTab("login")}
            role="button"
          />

          <>
            <h1>Datacrown</h1>
            <p>The world best voucher website</p>
          </>
        </div>
        {currentTab === "login" && <Login />}
        {currentTab === "register" && <Register />}
        {currentTab === "forgotPassword" && <ForgotPassword />}
      </div>
    </StyledAuthContainer>
  );
}
