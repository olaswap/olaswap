import styled from "styled-components";

export const StyledAuthContainer = styled.section`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;

  @media (max-width: 768px) {
    padding: 20px;
  }
  .authentication-container {
    max-width: 450px;
    flex-grow: 1;
    padding: 40px 50px;
    background-color: var(--white-color);
    box-shadow: 0 0.75rem 1.5rem rgba(18, 38, 63, 0.03);

    h1 {
      font-size: 25px;
      font-weight: 700;
      color: var(--black-color);
    }

    p {
      margin-bottom: 10px;
      font-size: 15px;
      color: var(--black-color);
    }

    @media (max-width: 768px) {
      width: 100%;
      padding: 20px 30px;
      padding-bottom: 30px;
    }
  }
`;

export const StyledAuth = styled.section`
  h3 {
    font-weight: 600;
    color: var(--black-color);
    margin-bottom: 5px;
    text-align: center;

    font-size: 18px;
    margin-top: 0;
    margin-bottom: 20px;
  }

  p {
    text-align: center;
    color: var(--gray-color);
    font-size: 14px;
    font-weight: 500;
    margin-bottom: 0;
    span {
      color: var(--primary-color);
      margin-left: 5px;
    }
  }

  h5 {
    text-align: right;
    font-size: 14px;
    font-weight: 500;
    margin-top: 10px;
    color: var(--gray-color);

    a {
      color: var(--primary-color);
    }
  }

  h6 {
    text-align: center;
    font-size: 14px;
    font-weight: 500;
    margin-top: 10px;
    color: var(--gray-color);

    a {
      color: var(--primary-color);
    }
  }

  .terms-of-use {
    font-weight: 500;
    color: var(--gray-color);
    font-size: 11px;
    margin-top: 10px;
    margin-bottom: 10px;
    @media (max-width: 768px) {
      font-size: 9px;
    }
    .terms {
      color: var(--primary-color);
    }
  }
`;

export const StyledEnterCode = styled.div`
  h6 {
    color: var(--gray-color);
    font-weight: 500;
    font-size: 15px;
    text-align: center;
    margin-bottom: 30px;
    margin-top: 15px;
    line-height: 20px;

    span {
      color: var(--primary-color);
      font-weight: 600;
    }
    strong {
      color: var(--faint-color);
    }
  }
`;
