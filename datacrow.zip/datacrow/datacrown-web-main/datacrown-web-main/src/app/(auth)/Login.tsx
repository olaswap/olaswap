"use client";

import { useFormik } from "formik";
import * as yup from "yup";
import Input from "@/components/Input";
import FormControl from "@/components/FormControl";
import Button from "@/components/buttons";
import login from "./core/login";

import Link from "next/link";
import { StyledAuth } from "@/app/(auth)/style";

import { useDispatch } from "react-redux";
import { handleAuthTab } from "@/store/component";
import { handleSetAuthFields } from "@/store/auth/authSlice";
import useModal from "@/hooks/useModal";
import VerifyEmail from "./VerifyEmail";

const validationSchema = yup.object({
  email: yup.string().required("This field is required"),
  password: yup
    .string()
    .min(6, "Mininum of 6 characters")
    .required("This field is required"),
});

export interface AuthModalProps {
  handleCancel: VoidFunction;
}

export default function Login() {
  const { visible, handleCancel, showModal } = useModal();
  const dispatch = useDispatch();

  const handleFP = () => {
    dispatch(handleAuthTab("forgotPassword"));
    dispatch(handleSetAuthFields({ email: formik.values.email }));
  };

  const { state, handleSubmit } = login(showModal);
  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validationSchema,
    onSubmit: (values) => {
      handleSubmit(values);
    },
  });

  return (
    <>
      <StyledAuth>
        <h3>Login</h3>
        <form
          onSubmit={formik.handleSubmit}
          className="animate__animated animate__fadeIn animate__slow"
        >
          <Input
            label="Email"
            name="email"
            id="email"
            type="email"
            value={formik.values.email}
            onChange={formik.handleChange}
            error={formik.touched.email && Boolean(formik.errors.email)}
            helperText={formik.touched.email && formik.errors.email}
            placeholder="example@gmail.com"
          />

          <FormControl
            name="password"
            label="Password"
            id="password"
            value={formik.values.password}
            onChange={formik.handleChange}
            error={formik.touched.password && Boolean(formik.errors.password)}
            helperText={formik.touched.password && formik.errors.password}
            placeholder="******"
          />

          <h5 className="mt-3">
            <Link href="#" onClick={handleFP}>
              Forgot Password ?
            </Link>
          </h5>
          <Button
            label="Login"
            className="btn__primary mt-3"
            disabled={!formik.isValid}
            loading={state.loading}
          />
          <p className="mt-3">
            Don’t have an account?{" "}
            <span
              role="button"
              onClick={() => dispatch(handleAuthTab("register"))}
            >
              Register
            </span>
          </p>
        </form>
      </StyledAuth>
      <VerifyEmail visible={visible} handleCancel={handleCancel} />
    </>
  );
}
