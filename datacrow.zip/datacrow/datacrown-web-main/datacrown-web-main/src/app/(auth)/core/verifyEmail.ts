import { useReducer } from "react";
import { useVerifyEmailMutation } from "@/store/auth";
import { VerifyEmail } from "@/store/auth/types";
import { init, reducer } from "@/reducers/post";
import * as type from "@/reducers/action";
import {
  isFetchBaseQueryError,
  isErrorWithMessage,
} from "@/helpers/formatError";
import misc from "@/helpers/misc";
import { notify } from "@/components/toast";
import { useRouter } from "next/navigation";

export default function Request(closeModal: VoidFunction) {
  const [req] = useVerifyEmailMutation();
  const [state, dispatch] = useReducer(reducer, init);
  const navigate = useRouter();

  const handleSubmit = async (props: VerifyEmail) => {
    dispatch({ type: type.LOADING });
    try {
      await req(props).unwrap();
      dispatch({ type: type.SUCCESS });
      closeModal();
      navigate.replace("/d/home");
    } catch (err) {
      if (isFetchBaseQueryError(err)) {
        dispatch({ type: type.FAILED });
        notify.warning(misc.errorMsg(err));
      } else if (isErrorWithMessage(err)) {
        dispatch({ type: type.ERROR });
        notify.error(misc.errorMsg(err));
      }
    }
  };

  return { state, handleSubmit };
}
