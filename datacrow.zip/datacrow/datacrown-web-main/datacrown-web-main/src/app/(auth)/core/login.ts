import { useReducer } from "react";
import { useLoginMutation } from "@/store/auth";
import { Login } from "@/store/auth/types";
import { init, reducer } from "@/reducers/post";
import * as type from "@/reducers/action";
import {
  isFetchBaseQueryError,
  isErrorWithMessage,
} from "@/helpers/formatError";
import misc from "@/helpers/misc";
import { notify } from "@/components/toast";

import { useDispatch } from "react-redux";
import { handleSetAuthFields } from "@/store/auth/authSlice";
import { useRouter } from "next/navigation";

export default function Request(showModal: VoidFunction) {
  const [req] = useLoginMutation();
  const [state, dispatch] = useReducer(reducer, init);
  const dispatchR = useDispatch();
  const navigate = useRouter();
  const handleSubmit = async (props: Login) => {
    dispatch({ type: type.LOADING });
    try {
      await req(props).unwrap();
      dispatch({ type: type.SUCCESS });
      navigate.replace("/d/home");
    } catch (err) {
      if (isFetchBaseQueryError(err)) {
        dispatch({ type: type.FAILED });
        if (misc.errorMsg(err) === "You must verify your email to continue.") {
          dispatchR(handleSetAuthFields({ email: props.email }));
          showModal();
        } else {
          notify.warning(misc.errorMsg(err));
        }
      } else if (isErrorWithMessage(err)) {
        dispatch({ type: type.ERROR });
        notify.error(misc.errorMsg(err));
      }
    }
  };

  return { state, handleSubmit };
}
