import { useReducer } from "react";
import { useRegisterMutation } from "@/store/auth";
import { Register } from "@/store/auth/types";
import { init, reducer } from "@/reducers/post";
import * as type from "@/reducers/action";
import {
  isFetchBaseQueryError,
  isErrorWithMessage,
} from "@/helpers/formatError";
import misc from "@/helpers/misc";
import { notify } from "@/components/toast";
import { useDispatch } from "react-redux";
import { handleSetAuthFields } from "@/store/auth/authSlice";

const Request = (showModal: VoidFunction) => {
  const [register] = useRegisterMutation();
  const [state, dispatch] = useReducer(reducer, init);
  const dispatchR = useDispatch();

  const handleSubmit = async (props: Register) => {
    dispatch({ type: type.LOADING });
    try {
      await register(props).unwrap();
      dispatch({ type: type.SUCCESS });
      dispatchR(handleSetAuthFields({ email: props.email }));
      showModal();
    } catch (err) {
      if (isFetchBaseQueryError(err)) {
        dispatch({ type: type.FAILED });
        notify.warning(misc.errorMsg(err));
      } else if (isErrorWithMessage(err)) {
        dispatch({ type: type.ERROR });
        notify.error(misc.errorMsg(err));
      }
    }
  };

  return { state, handleSubmit };
};

export default Request;
