import { useReducer } from "react";
import { useSendOtpMutation } from "@/store/auth";
import { SendOTP } from "@/store/auth/types";
import { init, reducer } from "@/reducers/post";
import * as type from "@/reducers/action";
import {
  isFetchBaseQueryError,
  isErrorWithMessage,
} from "@/helpers/formatError";
import misc from "@/helpers/misc";
import { notify } from "@/components/toast";

export default function Request() {
  const [req] = useSendOtpMutation();
  const [state, dispatch] = useReducer(reducer, init);

  const handleSubmit = async (props: SendOTP) => {
    dispatch({ type: type.LOADING });

    try {
      await req(props).unwrap();
      dispatch({ type: type.SUCCESS });
      notify.success("OTP sent");
    } catch (err) {
      if (isFetchBaseQueryError(err)) {
        dispatch({ type: type.FAILED });
        notify.warning(misc.errorMsg(err));
      } else if (isErrorWithMessage(err)) {
        dispatch({ type: type.ERROR });
        notify.error(misc.errorMsg(err));
      }
    }
  };

  return { state, handleSubmit };
}
