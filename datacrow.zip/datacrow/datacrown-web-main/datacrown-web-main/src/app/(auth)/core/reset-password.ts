import { useReducer } from "react";
import { useResetPasswordMutation } from "@/store/auth";
import { ResetPassword } from "@/store/auth/types";
import { init, reducer } from "@/reducers/post";
import * as type from "@/reducers/action";
import {
  isFetchBaseQueryError,
  isErrorWithMessage,
} from "@/helpers/formatError";
import misc from "@/helpers/misc";
import { notify } from "@/components/toast";
import { useRouter } from "next/navigation";

export default function Request() {
  const [resetPassword] = useResetPasswordMutation();
  const [state, dispatch] = useReducer(reducer, init);
  const navigate = useRouter();

  const handleSubmit = async (props: ResetPassword) => {
    dispatch({ type: type.LOADING });
    try {
      const res = await resetPassword(props).unwrap();
      dispatch({ type: type.SUCCESS });
      notify.alertSuccess(res.message, "", navigate.push("/"));
    } catch (err) {
      if (isFetchBaseQueryError(err)) {
        dispatch({ type: type.FAILED });
        notify.warning(misc.errorMsg(err));
      } else if (isErrorWithMessage(err)) {
        dispatch({ type: type.ERROR });
        notify.error(misc.errorMsg(err));
      }
    }
  };

  return { state, handleSubmit };
}
