import { useReducer } from 'react';
import { useForgotPasswordMutation } from '@/store/auth';
import { ForgotPassword } from '@/store/auth/types';
import { init, reducer } from '@/reducers/post';
import * as type from '@/reducers/action';
import {
  isFetchBaseQueryError,
  isErrorWithMessage,
} from '@/helpers/formatError';
import misc from '@/helpers/misc';
import { notify } from '@/components/toast';
import { useDispatch } from 'react-redux';
import { handleAuthTab } from '@/store/component';

export default function Request() {
  const [req] = useForgotPasswordMutation();
  const [state, dispatch] = useReducer(reducer, init);
  const dispatchR = useDispatch();
  const handleSubmit = async (props: ForgotPassword) => {
    dispatch({ type: type.LOADING });
    try {
      const res = await req(props).unwrap();
      dispatch({ type: type.SUCCESS });
      notify.alertSuccess(res.message, '');
      dispatchR(handleAuthTab('login'));
    } catch (err) {
      if (isFetchBaseQueryError(err)) {
        dispatch({ type: type.FAILED });
        notify.warning(misc.errorMsg(err));
      } else if (isErrorWithMessage(err)) {
        dispatch({ type: type.ERROR });
        notify.error(misc.errorMsg(err));
      }
    }
  };

  return { state, handleSubmit };
}
