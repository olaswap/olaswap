"use client";

import { useFormik } from "formik";
import * as yup from "yup";
import Input from "@/components/Input";
import Button from "@/components/buttons";
import forgotPassword from "./core/forgot-password";
import { StyledAuth } from "@/app/(auth)/style";
import { selectAuthFields } from "@/store/auth/authSlice";
import { useSelector } from "react-redux";

const validationSchema = yup.object({
  email: yup
    .string()
    .email("Must be a valid email")
    .required("This field is required"),
});

export default function ForgotPassword() {
  const { state, handleSubmit } = forgotPassword();
  const { email } = useSelector(selectAuthFields);
  const formik = useFormik({
    initialValues: {
      email,
    },
    validationSchema,
    onSubmit: (values) => {
      handleSubmit(values);
    },
  });

  return (
    <StyledAuth>
      <h3>Forgot Password</h3>
      <form
        onSubmit={formik.handleSubmit}
        className="animate__animated animate__fadeIn animate__slow"
      >
        <Input
          label="Email Address"
          name="email"
          id="email"
          type="email"
          placeholder="example@gmail.com"
          value={formik.values.email}
          onChange={formik.handleChange}
          error={formik.touched.email && Boolean(formik.errors.email)}
          helperText={formik.touched.email && formik.errors.email}
        />
        <Button
          label="Recover"
          className="btn__primary mt-3"
          disabled={!formik.isValid}
          loading={state.loading}
        />
      </form>
    </StyledAuth>
  );
}
