import PinInput from "react-pin-input";
import Button from "@/components/buttons";
import verifyEmail from "./core/verifyEmail";
import resendOTP from "./core/sendOtp";
import { StyledEnterCode } from "./style";
import Spinner from "@/components/spinner/small";
import { useSelector } from "react-redux";
import { selectAuthFields } from "@/store/auth/authSlice";
import Modal from "@/components/modal";

export interface Props {
  visible: boolean;
  handleCancel: VoidFunction;
}

export default function VerifyEmail(props: Props) {
  const { handleCancel, visible } = props;
  const { state: stateR, handleSubmit: handleResend } = resendOTP();
  const { state, handleSubmit } = verifyEmail(handleCancel);
  const { email } = useSelector(selectAuthFields);

  return (
    <Modal
      title="Enter Code"
      visible={visible}
      handleCancel={handleCancel}
      closeIcon
    >
      <StyledEnterCode>
        <h6>
          An OTP has been sent <strong>{email}</strong> Enter OTP to confirm
          your account{" "}
          <span
            role="button"
            className="resend-otp"
            onClick={() => handleResend({ type: "EMAIL_VERIFICATION", email })}
          >
            <Spinner label="Resend Code" loading={stateR.loading} />
          </span>
        </h6>

        <PinInput
          focus
          length={4}
          initialValue=""
          secret
          type="numeric"
          inputMode="number"
          onComplete={(value: string) => {
            handleSubmit({ token: value });
          }}
          autoSelect={true}
          regexCriteria={/^[ A-Za-z0-9_@./#&+-]*$/}
          disabled={state.loading ? true : false}
        />
        <Button
          label="Verify"
          className="btn__primary"
          loading={state.loading}
        />
      </StyledEnterCode>
    </Modal>
  );
}
