"use client";
import { useFormik } from "formik";
import * as yup from "yup";
import FormControl from "@/components/FormControl";
import Input from "@/components/Input";
import Button from "@/components/buttons";
import Image from "next/image";
import resetPassword from "../../core/reset-password";
import { useParams } from "next/navigation";
import { StyledAuth, StyledAuthContainer } from "@/app/(auth)/style";
import Link from "next/link";
import { IMAGES } from "@/constant";

const validationSchema = yup.object({
  newPassword: yup
    .string()
    .required("This field is required")
    .min(6, "Mininum of 6 characters"),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref("newPassword"), undefined], "Passwords must match")
    .required("This field is required"),
});

export default function ResetPassword() {
  const params = useParams();
  const token = params?.slug ? params?.slug[0] : "";

  const { state, handleSubmit } = resetPassword();
  const formik = useFormik({
    initialValues: {
      newPassword: "",
      confirmPassword: "",
    },
    validationSchema,
    onSubmit: (values) => {
      handleSubmit({ password: values.newPassword, token });
    },
  });

  return (
    <StyledAuthContainer>
      <StyledAuth>
        <div className="authentication-container">
          <p className="text-center">
            <Link href="/">
              <Image
                src={IMAGES.logo}
                alt="App Logo"
                width={70}
                height={55}
                className="logo"
              />
            </Link>
          </p>
          <h3>Set New Password</h3>
          <form onSubmit={formik.handleSubmit}>
            <FormControl
              label="New Password"
              id="newPassword"
              name="newPassword"
              placeholder="******"
              value={formik.values.newPassword}
              onChange={formik.handleChange}
              error={
                formik.touched.newPassword && Boolean(formik.errors.newPassword)
              }
              helperText={
                formik.touched.newPassword && formik.errors.newPassword
              }
            />

            <Input
              label="Confirm Password"
              name="confirmPassword"
              id="confirmPassword"
              type="password"
              placeholder="******"
              value={formik.values.confirmPassword}
              onChange={formik.handleChange}
              error={
                formik.touched.newPassword &&
                Boolean(formik.errors.confirmPassword)
              }
              helperText={
                formik.touched.confirmPassword && formik.errors.confirmPassword
              }
            />
            <Button
              loading={state.loading}
              label="Reset Now"
              className="btn__primary mt-3"
            />
          </form>
        </div>
      </StyledAuth>
    </StyledAuthContainer>
  );
}
