import ResetPassword from '.';
import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'NasoBet - Reset Password',
};

export default function page() {
  return <ResetPassword />;
}
