"use client";

import { useFormik } from "formik";
import * as yup from "yup";
import Input from "@/components/Input";
import FormControl from "@/components/FormControl";
import Button from "@/components/buttons";
import register from "./core/register";
import Link from "next/link";
import { useParams } from "next/navigation";
import { StyledAuth } from "@/app/(auth)/style";
import { handleAuthTab } from "@/store/component";
import { useDispatch } from "react-redux";
import useModal from "@/hooks/useModal";
import VerifyEmail from "./VerifyEmail";

const validationSchema = yup.object({
  email: yup
    .string()
    .email("Must be a valid email")
    .required("This field is required"),
  phoneNumber: yup.string().required("This field is required"),
  password: yup
    .string()
    .min(6, "Mininum of 6 characters")
    .required("This field is required"),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref("password"), undefined], "Passwords must match")
    .required("This field is required"),
});

export default function Register() {
  const { visible, handleCancel, showModal } = useModal();
  const dispatch = useDispatch();

  const { state, handleSubmit } = register(showModal);
  const params = useParams();
  const referralCode = params?.slug ? params?.slug[0] : "";

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
      confirmPassword: "",
      phoneNumber: "",
    },
    validationSchema,
    onSubmit: (values) => {
      handleSubmit({ ...values, referralCode });
    },
  });
  return (
    <>
      <StyledAuth>
        <h3>Register</h3>
        <form
          onSubmit={formik.handleSubmit}
          className="animate__animated animate__fadeIn animate__slow"
        >
          <Input
            label="Email"
            name="email"
            id="email"
            type="email"
            value={formik.values.email}
            onChange={formik.handleChange}
            error={formik.touched.email && Boolean(formik.errors.email)}
            helperText={formik.touched.email && formik.errors.email}
            placeholder="example@gmail.com"
          />

          <Input
            label="Phone Number"
            name="phoneNumber"
            id="phoneNumber"
            type="text"
            value={formik.values.phoneNumber}
            onChange={formik.handleChange}
            error={
              formik.touched.phoneNumber && Boolean(formik.errors.phoneNumber)
            }
            helperText={formik.touched.phoneNumber && formik.errors.phoneNumber}
            placeholder="08012345678"
          />

          <FormControl
            name="password"
            label="Password"
            id="password"
            value={formik.values.password}
            onChange={formik.handleChange}
            error={formik.touched.password && Boolean(formik.errors.password)}
            helperText={formik.touched.password && formik.errors.password}
            placeholder="******"
          />

          <FormControl
            label="Confirm Password"
            name="confirmPassword"
            id="confirmPassword"
            value={formik.values.confirmPassword}
            onChange={formik.handleChange}
            error={
              formik.touched.confirmPassword &&
              Boolean(formik.errors.confirmPassword)
            }
            helperText={
              formik.touched.confirmPassword && formik.errors.confirmPassword
            }
            placeholder="****"
            isHideEye
          />

          <div className="terms-of-use">
            <span> By continuing I agree to the</span>
            <Link href={`/terms`} target="_blank" className="terms">
              <span> Terms</span> <span>and</span>
              <span> Conditions</span>
            </Link>
          </div>

          <Button
            label="Register"
            className="btn__primary mt-3"
            loading={state.loading}
            disabled={!formik.isValid}
          />
          <p className="mt-3">
            Already have an account?
            <span
              role="button"
              onClick={() => dispatch(handleAuthTab("login"))}
            >
              Login
            </span>
          </p>
        </form>
      </StyledAuth>
      <VerifyEmail visible={visible} handleCancel={handleCancel} />
    </>
  );
}
