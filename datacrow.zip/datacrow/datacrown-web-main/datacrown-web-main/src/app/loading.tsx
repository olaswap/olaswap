"use client";

import Image from "next/image";
import { StyledFallback } from "@/components/utility/style";
import { IMAGES } from "@/constant";

export default function Loading() {
  return (
    <StyledFallback>
      <p>
        <Image src={IMAGES.logo} alt="App logo" width={150} height={100} />
      </p>
    </StyledFallback>
  );
}
