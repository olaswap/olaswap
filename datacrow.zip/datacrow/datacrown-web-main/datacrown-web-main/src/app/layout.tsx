import type { Metadata } from "next";
import { Inter } from "next/font/google";
import ParentLayout from "@/layout/RootLayout";
import { SpeedInsights } from "@vercel/speed-insights/next";
import { Analytics } from "@vercel/analytics/react";
import "animate.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "../style/globals.scss";
import "../style/otp.scss";
import { Toaster } from "react-hot-toast";

const inter = Inter({
  // weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "DataCrown",
  description:
    "Buy Cheap Internet Data Plan and Airtime Recharge for Airtel, 9mobile, GLO, MTN, Pay DSTV, GOTV, PHCN.",
  openGraph: {
    url: "https://www.dcr.com.ng",
    siteName: "DataCrown.",
    description: `Buy Cheap Internet Data Plan and Airtime Recharge for Airtel, 9mobile, GLO, MTN, Pay DSTV, GOTV, PHCN.`,
    locale: "en_NG",
    type: "website",
  },
  authors: [{ name: "Alade Computer Group of Company", url: "https://www.dcr.com.ng" }],
  generator: "Alade Computer Group of Company",
  creator: "Alade Computer Group of Company",
  keywords: "Airtel, 9mobile, GLO, MTN, Pay DSTV, GOTV, PHCN.",
};



export const viewport = {
  width: 1,
  themeColor: "#ffffff",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">

      <link rel="dns-prefetch" href="//www.google.com" />
<link rel="alternate" type="application/rss+xml" title="Datacrown &raquo; Feed" href="https://dcr.com.ng" />
<link rel="alternate" type="application/rss+xml" title="DC &raquo; Comments Feed" href="https://dcr.com.ng" />

      <body className={inter.className}>
        <Toaster position="bottom-center" containerClassName="hot-toast" />
        <ParentLayout>
          {children}
          <SpeedInsights />
          <Analytics />
        </ParentLayout>
        
      </body>
    </html>
  );
}
