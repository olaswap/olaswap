import Page from "./(auth)";

export default function Index() {
  return <Page />;
}
