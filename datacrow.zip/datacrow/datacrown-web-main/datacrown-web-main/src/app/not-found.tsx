"use client";
import Link from "next/link";
import { Styled404 } from "@/components/utility/error-404";

export default function NotFound() {
  return (
    <Styled404>
      <div className="content">
        <div className="e-404 animate__animated animate__fadeIn animate__slow">
          <h4>404</h4>
        </div>
        <h3>PAGE NOT FOUND</h3>
        <Link href="/">Go Home</Link>
      </div>
    </Styled404>
  );
}
