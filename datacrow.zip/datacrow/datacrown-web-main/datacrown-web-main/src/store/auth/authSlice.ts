import { createSlice } from "@reduxjs/toolkit";
import { onboardApi } from "@/store/auth";
import { RootState } from "@/store/app/store";
import { setAuthCookie } from "@/helpers/storage";

interface AccessToken {
  expireAt: number;
  isAuthenticated: boolean;
}
interface AuthFields {
  username: string;
  email: string;
}

interface Props {
  accessToken: AccessToken;
  authFields: AuthFields;
}

const initialState: Props = {
  accessToken: { expireAt: 0, isAuthenticated: false },
  authFields: { username: "", email: "" },
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    handleSetAuthFields(state, action) {
      state.authFields = { ...state.authFields, ...action.payload };
    },

    handleLogout(state) {
      state.authFields = initialState.authFields;
      state.accessToken = initialState.accessToken;
    },
  },
  extraReducers: (builder) => {
    builder.addMatcher(
      onboardApi.endpoints.login.matchFulfilled,
      (state, { payload }) => {
        setAuthCookie({
          expireAt: payload.data.expiresAt,
          accessToken: payload.data.accessToken,
        });

        state.accessToken = {
          expireAt: payload.data.expiresAt,
          isAuthenticated: true,
        };
      }
    );
    builder.addMatcher(
      onboardApi.endpoints.verifyEmail.matchFulfilled,
      (state, { payload }) => {
        setAuthCookie({
          expireAt: payload.data.expiresAt,
          accessToken: payload.data.accessToken,
        });
        state.accessToken = {
          expireAt: payload.data.expiresAt,
          isAuthenticated: true,
        };
      }
    );

    builder.addMatcher(
      onboardApi.endpoints.register.matchFulfilled,
      (state, { payload }) => {
        if (payload.data.emailConfirmed) {
          setAuthCookie({
            expireAt: payload.data.expiresAt,
            accessToken: payload.data.accessToken,
          });

          state.accessToken = {
            expireAt: payload.data.expiresAt,
            isAuthenticated: true,
          };
        }
      }
    );
  },
});

export const { handleSetAuthFields, handleLogout } = authSlice.actions;
export const selectCurrentToken = (state: RootState) => state.auth.accessToken;
export const selectAuthFields = (state: RootState) => state.auth.authFields;
export default authSlice.reducer;
