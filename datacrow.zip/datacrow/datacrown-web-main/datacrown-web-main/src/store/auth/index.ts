import { extendedApi } from "../app/api";
import * as url from "../../helpers/url";
export const onboardApi = extendedApi.injectEndpoints({
  endpoints: (build) => ({
    register: build.mutation({
      query: (body) => ({
        url: url.REGISTER,
        method: "POST",
        body,
      }),
    }),

    login: build.mutation({
      query: (body) => ({
        url: url.LOGIN,
        method: "POST",
        body,
      }),
    }),

    verifyEmail: build.mutation({
      query: (data) => ({
        url: url.CONFIRM_EMAIL,
        method: "POST",
        body: data,
      }),
    }),

    forgotPassword: build.mutation({
      query: (body) => ({
        url: url.FORGOT_PASSWORD,
        method: "POST",
        body,
      }),
    }),

    resetPassword: build.mutation({
      query: (body) => ({
        url: url.RESET_PASSWORD,
        method: "PUT",
        body,
      }),
    }),

    sendOtp: build.mutation({
      query: (data) => ({
        url: url.SEND_OTP,
        method: "POST",
        body: data,
      }),
    }),
  }),
});

export const {
  useRegisterMutation,
  useLoginMutation,
  useVerifyEmailMutation,
  useForgotPasswordMutation,
  useResetPasswordMutation,
  useSendOtpMutation,
} = onboardApi;
