export type Register = {
  email: string;
  password: string;
  referralCode?: string;
};
export type Login = { email: string; password: string };
export type AuthWithGoogle = { idToken: string; referralCode?: string };
export type ForgotPassword = { email: string };
export type ResetPassword = { password: string; token: string | undefined };
export type VerifyEmail = { token: string };
export type SendOTP = {
  type: "EMAIL_VERIFICATION" | "PHONE_VERIFICATION";
  email?: string;
};
