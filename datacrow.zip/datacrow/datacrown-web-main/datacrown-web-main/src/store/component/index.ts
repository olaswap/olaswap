import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../app/store";
import { IDataPlan } from "@/app/d/buy-data";

interface Props {
  authTab: string;
  selectedDataPlan: IDataPlan;
}

const initialState: Props = {
  authTab: "login",
  selectedDataPlan: {
    amount: 0,
    validity: "",
    plan: "",
    id: null,
    network: "",
  },
};

const componentsSlice = createSlice({
  name: "components",
  initialState,
  reducers: {
    handleAuthTab(state, action) {
      state.authTab = action.payload;
    },

    handleSelectedDataPlan(state, action) {
      state.selectedDataPlan = action.payload;
    },
  },
});

export const { handleAuthTab, handleSelectedDataPlan } =
  componentsSlice.actions;

export const selectAuthTab = (state: RootState) => state.components.authTab;
export const selectSelectedDataPlan = (state: RootState) =>
  state.components.selectedDataPlan;

export default componentsSlice.reducer;
