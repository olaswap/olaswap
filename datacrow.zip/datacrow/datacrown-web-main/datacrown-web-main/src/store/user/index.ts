import { extendedApi } from "../app/api";
import * as url from "../../helpers/url";
export const api = extendedApi.injectEndpoints({
  endpoints: (build) => ({
    profile: build.query({
      query: () => url.PROFILE,
      providesTags: ["Profile"],
      keepUnusedDataFor: 36000,
    }),

    changePassword: build.mutation({
      query: (data) => ({
        url: url.CHANGE_PASSWORD,
        method: "PUT",
        body: data,
      }),
    }),

    editProfile: build.mutation({
      query: (data) => ({
        url: url.EDIT_PROFILE,
        method: "PUT",
        body: data,
      }),
      invalidatesTags: ["Profile"],
    }),

    initializePayment: build.mutation({
      query: (data) => ({
        url: url.INITIALIZE_PAYMENT,
        method: "POST",
        body: data,
      }),
    }),

    buySubscription: build.mutation({
      query: (data) => ({
        url: url.BUY_SUBSCRIPTION,
        method: "POST",
        body: data,
      }),
    }),
    transactions: build.query({
      query: () => url.TRANSACTIONS,
      providesTags: ["Transactions"],
      keepUnusedDataFor: 36000,
    }),

    dataPlans: build.query({
      query: () => url.DATA_PLANS,
      keepUnusedDataFor: 36000,
    }),
    buyData: build.mutation({
      query: (data) => ({
        url: url.BUY_DATA,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Transactions"],
    }),
    buyAirtime: build.mutation({
      query: (data) => ({
        url: url.BUY_AIRTIME,
        method: "POST",
        body: data,
      }),
      invalidatesTags: ["Transactions"],
    }),
  }),
});

export const {
  useProfileQuery,
  useChangePasswordMutation,
  useEditProfileMutation,
  useInitializePaymentMutation,
  useBuySubscriptionMutation,
  useTransactionsQuery,
  useDataPlansQuery,
  useBuyAirtimeMutation,
  useBuyDataMutation,
} = api;
