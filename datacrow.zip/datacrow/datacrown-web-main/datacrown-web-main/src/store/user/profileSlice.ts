import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../app/store";
import { api } from ".";

type Profile = { success: boolean; isLoading: boolean; payload: any };
const initialState: Profile = { success: false, isLoading: false, payload: {} };

const profileSlice = createSlice({
  name: "profile",
  initialState,
  reducers: {},
  extraReducers: (build) => {
    build.addMatcher(
      api.endpoints.profile.matchFulfilled,
      (state, { payload }) => {
        state.isLoading = false;
        state.success = true;
        state.payload = payload;
      }
    );
    build.addMatcher(api.endpoints.profile.matchPending, (state) => {
      state.isLoading = true;
      state.success = false;
      state.payload = {};
    });
    build.addMatcher(api.endpoints.profile.matchRejected, (state) => {
      state.isLoading = false;
      state.success = false;
      state.payload = {};
    });
  },
});

export default profileSlice.reducer;
export const selectProfile = (state: RootState) => state.profile;
