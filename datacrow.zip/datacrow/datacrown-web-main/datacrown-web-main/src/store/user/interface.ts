export type User = { firstName: string; lastName: string };

export type ChangePassword = { currentPassword: string; newPassword: string };

export type EditProfile = {
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
  email?: string;
};
export type InitializePayment = {
  amount: string;
};

export type BuyData = {
  phoneNumber: string;
  amount: number;
  planId: number | null;
  network: string;
};

export type BuyAirtime = {
  phoneNumber: string;
  amount: number | string;
  network: string;
};
