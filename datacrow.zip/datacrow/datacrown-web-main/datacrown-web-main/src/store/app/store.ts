import {
  persistReducer,
  persistStore,
  FLUSH,
  REHYDRATE,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER,
} from "redux-persist";
import autoMergeLevel2 from "redux-persist/lib/stateReconciler/autoMergeLevel2";

import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { setupListeners } from "@reduxjs/toolkit/query";
import { extendedApi } from "./api";
import componentsGameReducer from "../component";
import authReducer from "../auth/authSlice";
import profileReducer from "../user/profileSlice";
import { createPersistStorage } from "./storage";

const persistConfig: any = {
  key: "root",
  storage: createPersistStorage(),
  stateReconciler: autoMergeLevel2,
  whitelist: ["auth"],
};

const reducers = combineReducers({
  [extendedApi.reducerPath]: extendedApi.reducer,
  components: componentsGameReducer,
  auth: authReducer,
  profile: profileReducer,
});

const persistedReducer = persistReducer(persistConfig, reducers);
export const store = configureStore({
  reducer: persistedReducer,
  middleware: (gDM: any) =>
    gDM({
      serializableCheck: false,
      immutableCheck: false,
      FLUSH,
      REHYDRATE,
      PAUSE,
      PERSIST,
      PURGE,
      REGISTER,
    }).concat(extendedApi.middleware),
});

setupListeners(store.dispatch);
export type RootState = ReturnType<typeof store.getState>;
export const persistor = persistStore(store);
