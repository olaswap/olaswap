/* eslint-disable no-unused-vars */
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { RootState } from "./store";
import { getAuthCookie } from "@/helpers/storage";
const baseUrl = process.env.BASE_URL;

const baseQuery = fetchBaseQuery({
  baseUrl,
  prepareHeaders: (headers, { getState }) => {
    const { isAuthenticated } = (getState() as RootState).auth.accessToken;
    if (isAuthenticated) {
      const token = getAuthCookie();
      headers.set("authorization", `Bearer ${token}`);
    }
    return headers;
  },
});

export const extendedApi = createApi({
  refetchOnReconnect: true,
  baseQuery: baseQuery,
  tagTypes: ["Profile", "Transactions"],
  endpoints: (builder) => ({}),
});
