import { useSelector } from "react-redux";
import { selectProfile } from "@/store/user/profileSlice";
import util from "@/helpers/utils";
import { selectCurrentToken } from "@/store/auth/authSlice";

export default function useUser() {
  const state = useSelector(selectProfile);
  const token = useSelector(selectCurrentToken);

  const isLoading = () => {
    if (state.isLoading && token) return true;
    else return;
  };

  const success = () => {
    if (state.success && token) return true;
    else return;
  };

  const payload = () => {
    if (success()) {
      return state.payload.data;
    }
  };

  const balance = () => {
    if (success()) {
      return util.numberFormat(payload().balance, 2);
    }
    return "0.0";
  };

  return {
    isSuccess: success(),
    isLoading: isLoading(),
    user: payload(),
    balance: balance(),
  };
}
