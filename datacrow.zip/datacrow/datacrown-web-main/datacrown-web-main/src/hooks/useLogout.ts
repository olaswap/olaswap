import { useDispatch } from "react-redux";
import { deleteCookie } from "@/helpers/storage";
import { handleLogout as userLogout } from "@/store/auth/authSlice";
import { api } from "@/store/user";
import { useRouter } from "next/navigation";

export default function useLogout() {
  const dispatch = useDispatch();
  const navigate = useRouter();
  const handleLogout = () => {
    localStorage.clear();
    navigate.replace("/");
    deleteCookie("accessToken");
    dispatch(api.util.resetApiState());
    dispatch(userLogout());
  };

  return handleLogout;
}
