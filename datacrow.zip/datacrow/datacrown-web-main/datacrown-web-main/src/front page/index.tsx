"use client";

import React from "react";
import Layout from "@/layout";
import { Icon } from "@iconify/react";
import { StyledHome } from "./style";
import useModal from "@/hooks/useModal";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { IMAGES } from "@/constant";
import useUser from "@/hooks/useUser";
import BuyAirtime from "@/components/subscriptions/buyAirtime";
import ComingSoon from "@/components/subscriptions/ComingSoon";

export default function Home() {
  const {
    visible: visibleT,
    handleCancel: handleCancelT,
    showModal: showModalT,
  } = useModal();

  const {
    visible: visibleA,
    handleCancel: handleCancelA,
    showModal: showModalA,
  } = useModal();

  const {
    visible: visibleO,
    handleCancel: handleCancelO,
    showModal: showModalO,
  } = useModal();

  const { balance } = useUser();
  const navigate = useRouter();

  return (
    <Layout>
      <StyledHome>
        <section className="hero-section">
          <div className="row">
            <div className="col-md-6">
              <div className="content">
                <h1>Buy Airtime, Data and Pay bills at a very best rate.</h1>
                <p>We can always be your plug.</p>
              </div>
            </div>
            <div className="col-md-6">
              <div className="img-container">
                <Image
                  src={IMAGES.heroImage}
                  alt="lady with phone picture"
                  className="img-fluid"
                  width={300}
                  height={300}
                />
              </div>
            </div>
          </div>
        </section>

        <div className="wallet-balance">
          <div>
            <h5>₦{balance}</h5>
            <p>Wallet Balance</p>
          </div>

          <button onClick={showModalT}>Topup</button>
        </div>
        

        <div className="action-buttons">
          <div role="button" onClick={showModalA}>
            <Icon icon="icon-park-outline:phone-call" />
            <p>Buy Airtime</p>
          </div>

          <div role="button" onClick={() => navigate.push("/d/buy-data")}>
            <Icon icon="mdi-light:wifi" />
            <p>Buy Data</p>
          </div>

          <div role="button" onClick={showModalO}>
            <Icon icon="carbon:course" />
            <p>Pay Bill</p>
          </div>

          <div role="button" onClick={showModalO}>
            <Icon icon="carbon:mountain" />
            <p>Card PIN</p>
          </div>

          {/* <div role="button" onClick={showModalO}>
            <Icon icon="mynaui:pay-circle" />
            <p>Pay</p>
          </div>

          <div role="button" onClick={showModalO}>
            <Icon icon="carbon:basketball" />
            <p>news</p>
          </div> */}
        </div>
      </StyledHome>

      <TopUpWallet visible={visibleT} handleCancel={handleCancelT} />
      <BuyAirtime visible={visibleA} handleCancel={handleCancelA} />
      <ComingSoon visible={visibleO} handleCancel={handleCancelO} />
    </Layout>
  );
}
