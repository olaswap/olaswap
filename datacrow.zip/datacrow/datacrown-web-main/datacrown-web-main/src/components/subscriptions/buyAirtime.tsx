"use client";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";

import Modal from "@/components/modal";
import { useFormik } from "formik";
import * as yup from "yup";
import buyAirtime from "./core/buyAirtime";
import Input from "../Input";
import Button from "../buttons";

import Select from "../Select";
export interface Props {
  visible: boolean;
  handleCancel: VoidFunction;
}

const validationSchema = yup.object({
  phoneNumber: yup.string().required("This field is required"),
  amount: yup.string().required("This field is required"),
  network: yup.string().required("This field is required"),
  proceed: yup.bool().oneOf([true], "This field is required"),
});

export default function BuyAirtime(props: Props) {
  const { visible, handleCancel } = props;
  const { state, handleSubmit } = buyAirtime(handleCancel);
  const formik = useFormik({
    initialValues: {
      phoneNumber: "",
      network: "",
      amount: "",
      proceed: false,
    },
    validationSchema,
    onSubmit: (values) => {
      handleSubmit(values);
    },
  });

  return (
    <Modal
      title="Buy Airtime"
      visible={visible}
      handleCancel={handleCancel}
      closeIcon
    >
      <form
        onSubmit={formik.handleSubmit}
        className="animate__animated animate__fadeIn animate__slow"
      >
        <Input
          label="Phone Number"
          name="phoneNumber"
          id="phoneNumber"
          type="text"
          value={formik.values.phoneNumber}
          onChange={formik.handleChange}
          error={
            formik.touched.phoneNumber && Boolean(formik.errors.phoneNumber)
          }
          helperText={formik.touched.phoneNumber && formik.errors.phoneNumber}
          placeholder="Enter phone Number"
        />

        <Select
          label="Select Network"
          name="network"
          id="network"
          value={formik.values.network}
          onChange={formik.handleChange}
          error={formik.touched.network && Boolean(formik.errors.network)}
          helperText={formik.touched.network && formik.errors.network}
          items={["mtn", "airtel", "glo", "9mobile"]}
        />

        <Input
          label="Amount"
          name="amount"
          id="amount"
          type="number"
          value={formik.values.amount}
          onChange={formik.handleChange}
          error={formik.touched.amount && Boolean(formik.errors.amount)}
          helperText={formik.touched.amount && formik.errors.amount}
          placeholder="Enter amount"
        />

        <FormControlLabel
          control={
            <Checkbox
              icon={<CheckBoxOutlineBlankIcon fontSize="large" />}
              checkedIcon={<CheckBoxIcon fontSize="large" />}
              id="proceed"
              name="proceed"
              checked={formik.values.proceed}
              onChange={formik.handleChange}
              color="primary"
            />
          }
          label="I confirm to proceed"
        />
        <Button
          label="Buy Now"
          className="btn__primary mt-3"
          disabled={!formik.isValid}
          loading={state.loading}
        />
      </form>
    </Modal>
  );
}
