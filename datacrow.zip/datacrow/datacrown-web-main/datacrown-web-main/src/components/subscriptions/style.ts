import styled from "styled-components";

export const StyledSubscriptionInfo = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  border: 1px solid #dfdbdb;
  padding: 10px 20px;
  margin-bottom: 20px;
  border-radius: 5px;

  div {
    display: flex;
    flex-direction: column;

    font-weight: 500;
    font-size: 15px;

    @media (max-width: 768px) {
      text-align: left;
      font-size: 14px;
    }

    span:first-child {
      font-weight: 600;
    }

    span:last-child {
      font-size: 12px;
    }
  }

  img {
    @media (max-width: 768px) {
      width: 20px;
      height: 20px;
    }
  }
`;
