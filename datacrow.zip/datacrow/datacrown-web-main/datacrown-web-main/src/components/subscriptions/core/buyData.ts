import { useReducer } from "react";
import { useBuyDataMutation } from "@/store/user";
import { BuyData } from "@/store/user/interface";
import { init, reducer } from "@/reducers/post";
import * as type from "@/reducers/action";
import {
  isFetchBaseQueryError,
  isErrorWithMessage,
} from "@/helpers/formatError";
import { notify } from "@/components/toast";
import misc from "@/helpers/misc";
import { useRouter } from "next/navigation";

const Request = (showModal: VoidFunction) => {
  const [req] = useBuyDataMutation();
  const [state, dispatch] = useReducer(reducer, init);
  const navigate = useRouter();
  const handleSubmit = async (props: BuyData) => {
    dispatch({ type: type.LOADING });
    try {
      const res = await req(props).unwrap();
      dispatch({ type: type.SUCCESS, payload: res.data });
      showModal();
      notify.alertSuccess(
        "Data purchased successfully",
        "",
        navigate.push("/d/home")
      );
    } catch (err) {
      if (isFetchBaseQueryError(err)) {
        dispatch({ type: type.FAILED });
        notify.warning(misc.errorMsg(err));
      } else if (isErrorWithMessage(err)) {
        dispatch({ type: type.ERROR });
        notify.error(misc.errorMsg(err));
      }
    }
  };

  return { state, handleSubmit };
};

export default Request;
