import { useReducer } from "react";
import { useBuyAirtimeMutation } from "@/store/user";
import { BuyAirtime } from "@/store/user/interface";
import { init, reducer } from "@/reducers/post";
import * as type from "@/reducers/action";
import {
  isFetchBaseQueryError,
  isErrorWithMessage,
} from "@/helpers/formatError";
import { notify } from "@/components/toast";
import misc from "@/helpers/misc";
import { useRouter } from "next/navigation";

const Request = (showModal: VoidFunction) => {
  const [req] = useBuyAirtimeMutation();
  const [state, dispatch] = useReducer(reducer, init);
  const navigate = useRouter();
  const handleSubmit = async (props: BuyAirtime) => {
    dispatch({ type: type.LOADING });
    try {
      const res = await req(props).unwrap();
      dispatch({ type: type.SUCCESS, payload: res.data });
      showModal();
      notify.alertSuccess(
        "Airtime purchased successfully",
        "",
        navigate.push("/d/home")
      );
    } catch (err) {
      if (isFetchBaseQueryError(err)) {
        dispatch({ type: type.FAILED });
        notify.warning(misc.errorMsg(err));
      } else if (isErrorWithMessage(err)) {
        dispatch({ type: type.ERROR });
        notify.error(misc.errorMsg(err));
      }
    }
  };

  return { state, handleSubmit };
};

export default Request;
