"use client";
import Modal from "@/components/modal";

export interface Props {
  visible: boolean;
  handleCancel: VoidFunction;
}

export default function ComingSoon(props: Props) {
  const { visible, handleCancel } = props;

  return (
    <Modal visible={visible} handleCancel={handleCancel} closeIcon>
      <h5 className="text-center">Comming soon...</h5>
    </Modal>
  );
}
