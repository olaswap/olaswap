"use client";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";

import Modal from "@/components/modal";
import { useFormik } from "formik";
import * as yup from "yup";
import buyData from "./core/buyData";
import Input from "../Input";
import Button from "../buttons";
import Image from "next/image";
import { StyledSubscriptionInfo } from "./style";
import { useSelector } from "react-redux";
import { selectSelectedDataPlan } from "@/store/component";
import util from "@/helpers/utils";
import misc from "@/helpers/misc";
export interface Props {
  visible: boolean;
  handleCancel: VoidFunction;
}

const validationSchema = yup.object({
  phoneNumber: yup
    .string()
    .matches(util.phoneRegExp(), "Invalid Phone Number")
    .required("This field is required"),
  proceed: yup.bool().oneOf([true], "This field is required"),
});

export default function BuyData(props: Props) {
  const selectedPlan = useSelector(selectSelectedDataPlan);
  const { visible, handleCancel } = props;
  const { state, handleSubmit } = buyData(handleCancel);

  const formik = useFormik({
    initialValues: {
      phoneNumber: "",
      proceed: false,
    },
    validationSchema,
    onSubmit: (values) => {
      const payload = {
        amount: selectedPlan.amount,
        planId: selectedPlan.id,
        plan: selectedPlan.plan,
        network: selectedPlan.network,
        phoneNumber: values.phoneNumber,
      };
      handleSubmit(payload);
    },
  });

  return (
    <Modal
      title="Buy Data"
      visible={visible}
      handleCancel={handleCancel}
      closeIcon
    >
      <form
        onSubmit={formik.handleSubmit}
        className="animate__animated animate__fadeIn animate__slow"
      >
        <StyledSubscriptionInfo>
          <div>
            <span>₦{util.numberFormat(selectedPlan.amount,2)}</span>{" "}
            <span>
              {selectedPlan.plan} - {selectedPlan.validity}
            </span>
          </div>
          <Image
            src={misc.findNetworkImage(selectedPlan.network)}
            alt={`${selectedPlan.network} logo`}
            width={30}
            height={30}
          />
        </StyledSubscriptionInfo>

        <Input
          label="Phone Number"
          name="phoneNumber"
          id="phoneNumber"
          type="text"
          value={formik.values.phoneNumber}
          onChange={formik.handleChange}
          error={
            formik.touched.phoneNumber && Boolean(formik.errors.phoneNumber)
          }
          helperText={formik.touched.phoneNumber && formik.errors.phoneNumber}
          placeholder="Enter phone Number"
        />

        <FormControlLabel
          control={
            <Checkbox
              icon={<CheckBoxOutlineBlankIcon fontSize="large" />}
              checkedIcon={<CheckBoxIcon fontSize="large" />}
              id="proceed"
              name="proceed"
              checked={formik.values.proceed}
              onChange={formik.handleChange}
              color="primary"
            />
          }
          label="I confirm to proceed"
        />
        <Button
          label="Buy Now"
          className="btn__primary mt-3"
          loading={state.loading}
        />
      </form>
    </Modal>
  );
}
