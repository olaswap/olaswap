import { Icon } from "@iconify/react";
import { useState } from "react";
import { StyledPasswordField } from "./style";

interface Props {
  name: string;
  id?: string;
  label?: string;
  placeholder?: string;
  value: string | number;
  error?: boolean | undefined;
  onChange?: any;
  helperText?: any;
  disabled?: boolean;
  isHideEye?: boolean;
}

const FormControl = (props: Props) => {
  const {
    name,
    id,
    label,
    value,
    placeholder,
    error = null,
    onChange,
    helperText = false,
    disabled = false,
    isHideEye,
    ...rest
  } = props;

  const [visible, setVisible] = useState(false);
  const handleToggle = () => setVisible(!visible);

  return (
    <StyledPasswordField>
      <label htmlFor="input">{label}</label>
      <div>
        <input
          name={name}
          placeholder={placeholder}
          id={id}
          type={visible ? "text" : "password"}
          disabled={disabled}
          value={value}
          onChange={onChange}
          autoComplete="off"
          {...rest}
        />
        {!isHideEye && (
          <Icon
            className="eye-icon"
            icon={visible ? "heroicons:eye" : "heroicons:eye-slash"}
            onClick={handleToggle}
            role="button"
          />
        )}
      </div>

      {error && (
        <span>
          <Icon icon="material-symbols:info" />
          &nbsp;
          {helperText}
        </span>
      )}
    </StyledPasswordField>
  );
};

export default FormControl;
