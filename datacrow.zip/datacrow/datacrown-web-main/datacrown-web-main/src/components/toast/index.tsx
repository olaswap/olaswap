import toast from "react-hot-toast";
import Swal from "sweetalert2";

export const notify = {
  success: function (message: string) {
    toast.custom(<span className="success">{message}</span>);
  },
  warning: function (message: string) {
    toast.custom(<span className="warning">{message}</span>);
  },
  error: function (message: string) {
    toast.custom(<span className="error">{message}</span>);
  },
  alertSuccess: function (title: string, msg: string, location?: any) {
    Swal.fire(title, msg, "success").then((result) => {
      if (result.isConfirmed && location) location();
    });
  },
};
