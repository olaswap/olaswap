import styled from "styled-components";
export const StyledTextField = styled.div`
  margin-bottom: 10px;

  label {
    margin-top: 5px;
    font-weight: 500;
    font-size: 15px;
    color: var(--black-color);
    @media (max-width: 992px) {
      font-size: 13px;
    }
  }
  input {
    width: 100%;
    padding: 12px 15px;
    margin-top: 5px;
    font-weight: 500;
    font-size: 13px;
    outline-color: var(--primary-color);
    border: 1px var(--border-color) solid;
    background-color: var(--white-color);
    color: var(--black-color);
    border-radius: 5px;
  }

  span {
    margin-top: 8px;
    font-weight: 600;
    font-size: 11px;
    display: flex;
    color: #c41533;

    svg {
      font-size: 15px;
      color: #c41533;
    }
  }
`;

export const StyledPasswordField = styled.div`
  margin-bottom: 10px;
  label {
    margin-top: 5px;
    font-weight: 500;
    font-size: 15px;
    color: var(--black-color);
    @media (max-width: 992px) {
      font-size: 13px;
    }
  }

  div {
    position: relative;

    input {
      width: 100%;
      padding: 12px 15px;
      margin-top: 5px;
      font-weight: 500;
      font-size: 13px;
      outline-color: var(--primary-color);
      border: 1px var(--border-color) solid;
      background-color: var(--white-color);
      color: var(--black-color);
      border-radius: 5px;
    }

    svg.eye-icon {
      position: absolute;
      top: 17px;
      right: 20px;
      font-size: 20px;
    }
  }

  span {
    display: flex;
    margin-top: 8px;
    font-weight: 600;
    font-size: 11px;
    color: #c41533;

    svg {
      font-size: 15px;
      color: #c41533;
    }
  }
`;

export const StyledSelectField = styled.div`
  margin-bottom: 10px;
  label {
    margin-top: 5px;
    font-weight: 500;
    font-size: 15px;
    color: var(--black-color);
    @media (max-width: 992px) {
      font-size: 13px;
    }
  }

  div {
    position: relative;

    select {
      width: 100%;
      padding: 12px 15px;
      padding-right: 40px;
      margin-top: 5px;
      font-weight: 500;
      font-size: 13px;
      outline-color: var(--primary-color);
      border: 1px var(--border-color) solid;
      background-color: var(--white-color);
      color: var(--black-color);
      appearance: none; /* Remove default arrow in other browsers */
      border-radius: 5px;
    }

    svg.eye-icon {
      position: absolute;
      top: 17px;
      right: 20px;
      font-size: 20px;
    }
  }

  span {
    display: flex;
    margin-top: 8px;
    font-weight: 600;
    font-size: 11px;
    color: #c41533;

    svg {
      font-size: 15px;
      color: #c41533;
    }
  }
`;
