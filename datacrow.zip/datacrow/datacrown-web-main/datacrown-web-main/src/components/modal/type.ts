export interface Props {
  visible: boolean;
  defaultScreen?: boolean;
  handleCancel?: VoidFunction;
  title?: string;
  smFullscreen?: boolean;
  closeIcon?: boolean;
  placement?: 'end' | 'start';
  minimize?:boolean;
  children: React.ReactNode;
}

export type ModalProps = { visible: boolean; handleCancel: () => void };
