import Modal from 'react-bootstrap/Modal';
import Title from './Title';
import { Props } from './type';
export default function MainModal(props: Props) {
  const { defaultScreen, visible, handleCancel, title, children } = props;
  return (
    <>
      <Modal
        fullscreen={defaultScreen ? '' : 'sm-down'}
        dialogClassName="modal-dialog"
        show={visible}
        onHide={handleCancel}
        className="my-modal"
        size='lg'
        
      >
        <Title title={title} />
        {children}
      </Modal>
    </>
  );
}
