import { Icon } from "@iconify/react";
import "./style.scss";

interface Props {
  title?: string;
  closeIcon?: boolean;
  handleCancel?: VoidFunction;
}

export default function ModalTitle(props: Props) {
  const { title, closeIcon, handleCancel } = props;
  return (
    <div className="modal-title-container">
      {closeIcon ? (
        <div>
          <h4>{title}</h4>
          <Icon icon="carbon:close" onClick={handleCancel} role="button" />
        </div>
      ) : (
        <div>
          <h4>{title}</h4>
        </div>
      )}
    </div>
  );
}
