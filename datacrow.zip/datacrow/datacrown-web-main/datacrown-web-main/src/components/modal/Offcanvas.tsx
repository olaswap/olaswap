import Offcanvas from "react-bootstrap/Offcanvas";
import { Props } from "./type";

export default function Mobile(props: Props) {
  const { visible, handleCancel, children } = props;
  return (
    <Offcanvas
      show={visible}
      onHide={handleCancel}
      placement={"end"}
      className="account-offcanvas"
    >
      <Offcanvas.Body>{children}</Offcanvas.Body>
    </Offcanvas>
  );
}
