import Modal from "react-bootstrap/Modal";
import Title from "./Title";
import { Props } from "./type";
import { ModalBody } from "react-bootstrap";

export default function MainModal(props: Props) {
  const { defaultScreen, closeIcon, visible, handleCancel, title, children } =
    props;

  return (
    <>
      <Modal
        fullscreen={defaultScreen ? "" : "sm-down"}
        dialogClassName="modal-dialog"
        show={visible}
        onHide={handleCancel}
        onBackdropClick={handleCancel}
        className="my-modal"
        // size="sm"
        scrollable
      >
        <Title
          title={title}
          closeIcon={closeIcon}
          handleCancel={handleCancel}
        />
        <ModalBody>{children}</ModalBody>
      </Modal>
    </>
  );
}
