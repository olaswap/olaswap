'use client';
import Skeleton from '@mui/material/Skeleton';

function SkeletonLoad() {
  return (
    <div style={{marginTop: 150}}>
      <Skeleton height={50} className="rect" />
      <Skeleton height={50} className="rect" />
      <Skeleton height={50} className="rect" />
    </div>
  );
}

export default SkeletonLoad;
