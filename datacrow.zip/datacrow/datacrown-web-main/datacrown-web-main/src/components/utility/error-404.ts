import styled from 'styled-components';
export const Styled404 = styled.div`
  height: 100vh;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;

  .content {
    max-width: 400px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    div {
      display: flex;
      align-items: center;

      h4 {
        font-weight: 600;
        color: var(--black-color);
        margin-top: 15px;
        font-size: 110px;
        margin-bottom: -15px;

        @media (max-width: 768px) {
          font-size: 90px;
        }
      }

      span {
        margin-left: 15px;
        margin-right: 15px;
        border: 2px solid var(--primary-color);
        border-radius: 100px;
        padding: 5px;
      }

      img {
        animation: spin 4s linear infinite;
      }
    }

    h3 {
      font-weight: 600;
      color: var(--gray-color);
      margin-top: 15px;
      margin-bottom: 10px;
      font-size: 35px;
      margin-bottom: 30px;

      @media (max-width: 768px) {
        font-size: 25px;
      }
    }

    a {
      background-color: var(--primary-color);
      color: var(--white-color);
      padding: 10px 50px;
      border-radius: 8px;
      font-weight: 500;
      text-decoration: none;
    }
  }

  @-moz-keyframes spin {
    100% {
      -moz-transform: rotate(360deg);
    }
  }
  @-webkit-keyframes spin {
    100% {
      -webkit-transform: rotate(360deg);
    }
  }
  @keyframes spin {
    100% {
      -webkit-transform: rotate(360deg);
      transform: rotate(360deg);
    }
  }
`;
