/* eslint-disable react-hooks/exhaustive-deps */
'use client';
import { useEffect } from 'react';
import useLogout from '@/hooks/useLogout';

const events = [
  'load',
  'mousemove',
  'mousedown',
  'click',
  'scroll',
  'keypress',
];

const AppLogout = ({ children }: { children: React.ReactNode }) => {
  const handleLogout = useLogout();
  let timer: any;
  const handleLogoutTimer = () => {
    timer = setTimeout(() => {
      resetTimer();
      Object.values(events).forEach((item) => {
        window.removeEventListener(item, resetTimer);
      });
      handleLogout();
    }, 60000 * 5); // 3 minutes
  };

  // this resets the timer if it exists.
  const resetTimer = () => {
    if (timer) clearTimeout(timer);
  };

  useEffect(() => {
    Object.values(events).forEach((item) => {
      window.addEventListener(item, () => {
        resetTimer();
        handleLogoutTimer();
      });
    });
  }, []);

  return children;
};

export default AppLogout;
