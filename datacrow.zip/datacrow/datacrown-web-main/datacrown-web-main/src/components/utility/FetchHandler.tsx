import Skeleton from "../Skeleton";
import util from "../../helpers/utils";
import { StyledFetchError } from "./style";

interface Props {
  isError?: boolean;
  error?: any;
  isLoading?: boolean;
  title?: string;
}

export default function FetchHandler(props: Props) {
  const { isLoading, isError, error, title } = props;

  return (
    <>
      {isLoading && <Skeleton />}
      {isError && (
        <ErrorMessage error={error} isError={isError} title={title} />
      )}
    </>
  );
}

const ErrorMessage = (props: Props) => {
  const { isError, error } = props;

  const messages = {
    404: {
      message: "Empty Records",
    },
    500: {
      message: "Internal server error",
    },
    0: {
      message: "Something went wrong",
    },
    1: {
      message: "No Internet Connection",
    },
  };

  const data = messages[util.fectchError(isError, error)];

  return <StyledFetchError>{data.message}</StyledFetchError>;
};
