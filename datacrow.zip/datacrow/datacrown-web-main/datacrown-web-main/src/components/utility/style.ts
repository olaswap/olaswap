"use client";
import styled from "styled-components";
export const StyledFetchError = styled.h6`
  font-weight: 400;
  color: var(--gray-color);
  font-size: 15px;
  text-align: center;
  margin-top: 150px;
`;

export const StyledFallback = styled.div`
  height: 100vh;
  @media (max-width: 768px) {
    height: calc(100vh - 7rem);
  }
  width: 100%;
  background-color: var(--card-bg-color);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  p {
    margin-bottom: 18px;
  }
`;

export const StyledAuthRequired = styled.div`
  display: flex;
  justify-content: center;

  div {
    text-align: center;
    max-width: 400px;
    margin-bottom: 40px;
    margin-top: 40px;
    h6 {
      font-size: 13px;
      color: var(--gray-color);
      font-weight: 500;
      text-align: center;
      margin-top: 20px;
      margin-bottom: 15px;
    }

    button {
      border: none;
      border-radius: 10px;
      padding: 5px;
      width: 100%;
      background-color: #222934;
      color: var(--faint-color);
      font-size: 13px;
      font-weight: 500;
    }
  }
`;
