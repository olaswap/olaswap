import { Icon } from "@iconify/react";
import { StyledSelectField } from "./style";

interface Props {
  name: string;
  id?: string;
  label?: string;
  placeholder?: string;
  value: string | number;
  error?: boolean | undefined;
  type?: string;
  onChange?: any;
  helperText?: any;
  disabled?: boolean;
  items: string[];
}

const Select = (props: Props) => {
  const {
    name,
    id,
    label,
    value,
    items,
    error = null,
    onChange,
    helperText = false,
    disabled = false,
    ...rest
  } = props;

  return (
    <StyledSelectField>
      <label htmlFor="input">{label}</label>
      <div>
        <select
          name={name}
          id={id}
          disabled={disabled}
          value={value}
          onChange={onChange}
          {...rest}
        >
          <option value="" selected disabled>
            ---
          </option>
          {items.map((item, idx) => (
            <option key={idx} value={item}>
              {item.toUpperCase()}
            </option>
          ))}
        </select>
        <Icon className="eye-icon" icon={"ci:caret-down-md"} role="button" />
      </div>

      {error && (
        <span>
          <Icon icon="material-symbols:info" />
          &nbsp;
          {helperText}
        </span>
      )}
    </StyledSelectField>
  );
};

export default Select;
