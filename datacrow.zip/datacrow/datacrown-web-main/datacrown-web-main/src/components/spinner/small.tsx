import { Icon } from '@iconify/react';

interface Props {
  loading: boolean;
  label: string;
}
export default function Spinner(props: Props) {
  const { loading, label } = props;

  return loading ? <Icon icon="eos-icons:loading" /> : label;
}
