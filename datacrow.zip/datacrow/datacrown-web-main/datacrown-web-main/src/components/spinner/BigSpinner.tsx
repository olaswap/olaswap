import './big-spinner.scss';
export default function BigSpinner() {
  return (
    <div className='big-spinner-container'>
      <div className="big-spinner"></div>
    </div>
  );
}
