import spinner from "@/assets/loading.svg";
import Image from "next/image";
import "./style.scss";

type Props = {
  label: string;
  loading?: boolean;
  className: string;
  disabled?: boolean;
  onClick?: (() => void) | any;
};

export default function Button(probs: Props) {
  const { label, loading = false, onClick, className, ...rest } = probs;
  return (
    <div className={`${className} `}>
      <button
        type="submit"
        {...(loading && { disabled: true })}
        onClick={onClick}
        {...rest}
      >
        {loading ? (
          <Image src={spinner} alt="spinner" width={25} height={25} />
        ) : (
          label
        )}
      </button>
    </div>
  );
}
