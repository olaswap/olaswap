import { Icon } from "@iconify/react";
import { StyledTextField } from "./style";

interface Props {
  name: string;
  id?: string;
  label?: string;
  placeholder?: string;
  value: string | number;
  error?: boolean | undefined;
  type?: string;
  onChange?: any;
  helperText?: any;
  disabled?: boolean;
}

const Input = (props: Props) => {
  const {
    name,
    id,
    label,
    value,
    placeholder,
    error = null,
    type = "text",
    onChange,
    helperText = false,
    disabled = false,
    ...rest
  } = props;

  return (
    <StyledTextField>
      <label htmlFor="input">{label}</label>
      <input
        name={name}
        placeholder={placeholder}
        id={id}
        type={type}
        disabled={disabled}
        value={value}
        onChange={onChange}
        autoComplete="off"
        {...rest}
      />

      {error && (
        <span>
          <Icon icon="material-symbols:info" />
          &nbsp;
          {helperText}
        </span>
      )}
    </StyledTextField>
  );
};

export default Input;
  