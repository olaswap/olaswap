"use client";
import Modal from "@/components/modal";
import { useFormik } from "formik";
import * as yup from "yup";
import changePassword from "./core/changePassword";
import Button from "../buttons";
import FormControl from "../FormControl";
export interface Props {
  visible: boolean;
  handleCancel: VoidFunction;
}

const validationSchema = yup.object({
  currentPassword: yup
    .string()
    .required("This field is required")
    .min(6, "Invalid Password"),
  newPassword: yup
    .string()
    .required("This field is required")
    .min(6, "Mininum of 6 characters"),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref("newPassword"), undefined], "Passwords must match")
    .required("This field is required"),
});

export default function ChangePassword(props: Props) {
  const { visible, handleCancel } = props;
  const { state, handleSubmit } = changePassword(handleCancel);
  const formik = useFormik({
    initialValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
    validationSchema,
    onSubmit: async (values, { resetForm }) => {
      await handleSubmit(values);
      resetForm();
    },
  });
  return (
    <Modal
      title="Change Password"
      visible={visible}
      handleCancel={handleCancel}
      closeIcon
    >
      <form
        onSubmit={formik.handleSubmit}
        className="animate__animated animate__fadeIn animate__slow"
      >
        <FormControl
          label="Current Password"
          name="currentPassword"
          id="currentPassword"
          value={formik.values.currentPassword || ""}
          onChange={formik.handleChange}
          error={
            formik.touched.currentPassword &&
            Boolean(formik.errors.currentPassword)
          }
          helperText={
            formik.touched.currentPassword && formik.errors.currentPassword
          }
          placeholder="****"
        />

        <FormControl
          label="New Password"
          name="newPassword"
          id="newPassword"
          value={formik.values.newPassword || ""}
          onChange={formik.handleChange}
          error={
            formik.touched.newPassword && Boolean(formik.errors.newPassword)
          }
          helperText={formik.touched.newPassword && formik.errors.newPassword}
          placeholder="****"
          isHideEye
        />

        <FormControl
          label="Confirm Password"
          name="confirmPassword"
          id="confirmPassword"
          value={formik.values.confirmPassword || ""}
          onChange={formik.handleChange}
          error={
            formik.touched.confirmPassword &&
            Boolean(formik.errors.confirmPassword)
          }
          helperText={
            formik.touched.confirmPassword && formik.errors.confirmPassword
          }
          placeholder="****"
          isHideEye
        />

        <Button
          label="Change"
          className="btn__primary mt-3"
          loading={state.loading}
        />
      </form>
    </Modal>
  );
}
