import { useReducer } from "react";
import { useChangePasswordMutation } from "@/store/user";
import { ChangePassword } from "@/store/user/interface";
import { init, reducer } from "@/reducers/post";
import * as type from "@/reducers/action";
import {
  isFetchBaseQueryError,
  isErrorWithMessage,
} from "@/helpers/formatError";
import { notify } from "@/components/toast";
import misc from "@/helpers/misc";

const Request = (showModal: VoidFunction) => {
  const [req] = useChangePasswordMutation();
  const [state, dispatch] = useReducer(reducer, init);

  const handleSubmit = async (props: ChangePassword) => {
    dispatch({ type: type.LOADING });
    try {
      const res = await req(props).unwrap();
      dispatch({ type: type.SUCCESS, payload: res.data });
      notify.success(res.message);
      showModal();
    } catch (err) {
      if (isFetchBaseQueryError(err)) {
        dispatch({ type: type.FAILED });
        notify.warning(misc.errorMsg(err));
      } else if (isErrorWithMessage(err)) {
        dispatch({ type: type.ERROR });
        notify.error(misc.errorMsg(err));
      }
    }
  };

  return { state, handleSubmit };
};

export default Request;
