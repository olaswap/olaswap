"use client";
import Modal from "@/components/modal";
import { useFormik } from "formik";
import * as yup from "yup";
import editProfile from "./core/editProfile";
import Input from "../Input";
import Button from "../buttons";
import useUser from "@/hooks/useUser";
export interface Props {
  visible: boolean;
  handleCancel: VoidFunction;
}

const validationSchema = yup.object({
  firstName: yup.string(),
  lastName: yup.string(),
  phoneNumber: yup.string(),
  email: yup.string(),
});

export default function MyProfile(props: Props) {
  const { visible, handleCancel } = props;
  const { state, handleSubmit } = editProfile(handleCancel);
  const { user } = useUser();

  const formik = useFormik({
    initialValues: {
      firstName: user?.firstName ? user?.firstName : "",
      lastName: user?.lastName ? user.lastName : "",
      phoneNumber: user?.phoneNumber ? user.phoneNumber : "",
      email: user?.email,
    },
    validationSchema,
    onSubmit: (values) => {
      handleSubmit(values);
    },
  });
  return (
    <Modal
      title="My Profile"
      visible={visible}
      handleCancel={handleCancel}
      closeIcon
    >
      <form
        onSubmit={formik.handleSubmit}
        className="animate__animated animate__fadeIn animate__slow"
      >
        <div className="row">
          <div className="col-6">
            <Input
              label="First Name"
              name="firstName"
              id="firstName"
              type="text"
              value={formik.values.firstName}
              onChange={formik.handleChange}
              error={
                formik.touched.firstName && Boolean(formik.errors.firstName)
              }
              helperText={formik.touched.firstName && formik.errors.firstName}
              placeholder="John"
            />
          </div>
          <div className="col-6">
            <Input
              label="Last Name"
              name="lastName"
              id="lastName"
              type="text"
              value={formik.values.lastName}
              onChange={formik.handleChange}
              error={formik.touched.lastName && Boolean(formik.errors.lastName)}
              helperText={formik.touched.lastName && formik.errors.lastName}
              placeholder="Doe"
            />
          </div>
        </div>

        <Input
          label="Phone Number"
          name="phoneNumber"
          id="phoneNumber"
          type="text"
          value={formik.values.phoneNumber}
          onChange={formik.handleChange}
          error={
            formik.touched.phoneNumber && Boolean(formik.errors.phoneNumber)
          }
          helperText={formik.touched.phoneNumber && formik.errors.phoneNumber}
          placeholder="08012345678"
        />

        <Input
          label="Email"
          name="email"
          id="email"
          type="email"
          value={formik.values.email}
          onChange={formik.handleChange}
          error={formik.touched.email && Boolean(formik.errors.email)}
          helperText={formik.touched.email && formik.errors.email}
          placeholder="Enter amount"
          disabled
        />

        <Button
          label="Save"
          className="btn__primary mt-3"
          disabled={!formik.isValid}
          loading={state.loading}
        />
      </form>
    </Modal>
  );
}
