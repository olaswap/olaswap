"use client";
import Modal from "@/components/modal";
import { useFormik } from "formik";
import * as yup from "yup";
import fundWallet from "./core/fundWallet";
import Input from "../Input";
import Button from "../buttons";
export interface Props {
  visible: boolean;
  handleCancel: VoidFunction;
}

const validationSchema = yup.object({
  amount: yup.string().required("This field is required"),
});

export default function TopUpWallet(props: Props) {
  const { visible, handleCancel } = props;
  const { state, handleSubmit } = fundWallet();
  const formik = useFormik({
    initialValues: {
      amount: "",
    },
    validationSchema,
    onSubmit: (values) => {
      handleSubmit(values);
    },
  });
  return (
    <Modal
      title="Top Up Wallet"
      visible={visible}
      handleCancel={handleCancel}
      closeIcon
    >
      <form
        onSubmit={formik.handleSubmit}
        className="animate__animated animate__fadeIn animate__slow"
      >
        <Input
          label="Amount"
          name="amount"
          id="amount"
          type="number"
          value={formik.values.amount}
          onChange={formik.handleChange}
          error={formik.touched.amount && Boolean(formik.errors.amount)}
          helperText={formik.touched.amount && formik.errors.amount}
          placeholder="Enter amount"
        />

        <Button
          label="Proceed"
          className="btn__primary mt-3"
          disabled={!formik.isValid}
          loading={state.loading}
        />
      </form>
    </Modal>
  );
}
