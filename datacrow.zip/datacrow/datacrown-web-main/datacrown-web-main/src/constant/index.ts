import IMAGES from "../assets";
export { IMAGES };
