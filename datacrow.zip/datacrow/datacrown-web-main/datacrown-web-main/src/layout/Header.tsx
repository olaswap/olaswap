"use client";
import { Icon } from "@iconify/react";

import Link from "next/link";
import Image from "next/image";
import { StyledHeader } from "./style";
import useModal from "@/hooks/useModal";
import { IMAGES } from "@/constant";
import SideMenu from "./SideMenu";

export default function Header() {
  const { visible, handleCancel, showModal } = useModal();

  return (
    <StyledHeader className="fixed-top">
      <div className="header-container container">
        <Link href="/d/home">
          <Image
            src={IMAGES.logo}
            alt="App Logo"
            width={60}
            height={50}
            className="logo"
          />
        </Link>

        <div className="icons">
          <Icon
            icon="heroicons-solid:menu-alt-4"
            role="button"
            onClick={showModal}
          />
        </div>
      </div>
      <SideMenu visible={visible} handleCancel={handleCancel} />
    </StyledHeader>
  );
}
