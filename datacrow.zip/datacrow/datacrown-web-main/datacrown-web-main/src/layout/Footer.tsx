import { Icon } from "@iconify/react";
import React from "react";
import { StyledFooter } from "./style";
import Link from "next/link";

export default function Footer() {
  return (
    <StyledFooter>
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <ul>
              <li>LOCATION</li>

              <li>
                Federal Housing elega <br /> Abeokuta Ogun State Nigeria.
              </li>
            </ul>
          </div>

          <div className="col-md-4">
            <ul>
              <li>GET HELP</li>

              <li>
                <a
                  href="https://wa.me/qr/462UYDOOO3DLB1"
                  target="_blank"
                  rel="noreferrer"
                >
                  Whatsapp Support 1
                </a>
              </li>

              <li>
                <a
                  href="https://wa.me/qr/WDG7DTSSJYC7L1"
                  target="_blank"
                  rel="noreferrer"
                >
                  Whatsapp Support 2
                </a>
              </li>
              <li>
                <a
                  href="mailto:aladecomputergroupofcompany@gmail.com"
                  target="_blank"
                  rel="noreferrer"
                >
                  Email
                </a>
              </li>
            </ul>
          </div>

          <div className="col-md-2">
            <ul>
              <li>LEGAL</li>
              <li>
                <Link href={`#`}>Privacy Policy</Link>
              </li>
              <li>
                <Link href={`#`}>Terms</Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="copyright">
          Copyright @{new Date().getFullYear()} DataCrown
          <div>
            <a href="#">
              <Icon icon="iconoir:instagram" />
            </a>
            <a href="https://www.facebook.com/profile.php?id=61558443740948">
              <Icon icon="ic:outline-facebook" />
            </a>
          </div>
        </div>
      </div>
    </StyledFooter>
  );
}
