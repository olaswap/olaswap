import styled from "styled-components";
export const StyledHeader = styled.header`
  padding-top: 10px;
  padding-bottom: 10px;
  background-color: rgba(255, 255, 255, 0.9);

  @media (max-width: 768px) {
    padding-top: 5px;
    padding-bottom: 5px;
  }

  .header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;

    @media (max-width: 768px) {
      padding: 10px;
    }

    a {
      color: var(--white-color);
    }

    img.logo {
      width: 50px;
      height: 45px;
      object-fit: cover;
      cursor: pointer;
    }

    .icons {
      svg {
        font-size: 45px;
        padding: 5px 10px;
        border-radius: 10px;
        border: 1px solid var(--border-color);
        &:last-child {
          margin-left: 10px;
        }
      }
    }
  }
`;

export const StyledSideMenu = styled.section`
  padding: 10px 20px;
  div {
    text-align: right;
    margin-top: 15px;

    svg {
      color: var(--black-color);
      font-size: 30px;
      margin-left: 20px;
    }
  }
  p {
    color: var(--black-color);
    margin-bottom: 25px;
    font-weight: 500;
    font-size: 18px;

    a {
      color: var(--black-color);
    }
  }
`;

export const StyledFooter = styled.section`
  background-color: var(--primary-color);
  margin-top: 80px;
  padding: 30px 0;

  ul {
    display: flex;
    flex-direction: column;
    padding: 0;

    li {
      margin-bottom: 10px;
      display: inline;

      font-size: 15px;
      color: var(--white-color);

      cursor: pointer;

      a {
        color: var(--white-color);
        margin: 0;
      }

      &:first-child {
        color: var(--white-color);
        font-weight: 600;
      }
    }
  }
  .copyright {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-top: 1px solid #646464;
    padding-top: 30px;
    font-size: 12px;
    color: var(--white-color);
    div {
      a {
        font-size: 20px;
        color: var(--white-color);
        &:nth-child(2) {
          margin-left: 10px;
        }
      }
    }
  }
`;
