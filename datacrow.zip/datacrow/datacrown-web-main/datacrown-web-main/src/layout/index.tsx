/* eslint-disable react-hooks/exhaustive-deps */
"use client";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { api } from "@/store/user";
import Header from "./Header";
import Footer from "./Footer";
import { useSelector } from "react-redux";
import { selectCurrentToken } from "@/store/auth/authSlice";
import AppLogout from "@/components/utility/AppLogout";

interface Props {
  children: React.ReactNode;
}

export default function Layout(props: Props) {
  const { children } = props;
  const dispatch = useDispatch();

  const { isAuthenticated } = useSelector(selectCurrentToken);

  useEffect(() => {
    if (isAuthenticated) {
      const req = api.endpoints.profile.initiate(undefined) as any;
      const result = dispatch(req);
      return result.unsubscribe;
    }
  }, [dispatch]);

  return (
    <AppLogout>
      <Header />
      <main className="container animate__animated animate__fadeIn">
        {children}
      </main>
      <Footer />
    </AppLogout>
  );
}
