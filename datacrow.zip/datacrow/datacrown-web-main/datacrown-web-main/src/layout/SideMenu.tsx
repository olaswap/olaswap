"use client";

import { Icon } from "@iconify/react";
import Modal from "@/components/modal/Offcanvas";
import { ModalProps } from "@/components/modal/type";
import { StyledSideMenu } from "./style";
import useLogout from "@/hooks/useLogout";
import MyProfile from "@/components/SideMenu/MyProfile";
import TopUpWallet from "@/components/SideMenu/TopUpWallet";
import ChangePassword from "@/components/SideMenu/ChangePassword";
import useModal from "@/hooks/useModal";
import { useRouter } from "next/navigation";
import useUser from "@/hooks/useUser";

export default function SideMenu(props: ModalProps) {
  const { visible, handleCancel } = props;
  const handleLogout = useLogout();
  const navigate = useRouter();
  const { isSuccess } = useUser();

  const {
    visible: visibleT,
    showModal: showModalT,
    handleCancel: handleCancelT,
  } = useModal();

  const {
    visible: visibleP,
    showModal: showModalP,
    handleCancel: handleCancelP,
  } = useModal();

  const {
    visible: visibleC,
    showModal: showModalC,
    handleCancel: handleCancelC,
  } = useModal();

  const onClick = (type: string) => {
    handleCancel();
    switch (type) {
      case "Home":
        navigate.push("/d/home");
        return;
      case "Transactions":
        navigate.push("/d/transactions");
        return;

      case "Top-up":
        showModalT();
        return;
      case "Profile":
        showModalP();
        return;

      case "Change Password":
        showModalC();
        return;
      case "Logout":
        handleLogout();
        return;
    }
  };

  return (
    <>
      <Modal visible={visible} placement="end" handleCancel={handleCancel}>
        <StyledSideMenu>
          <div>
            <Icon icon="carbon:close" onClick={handleCancel} role="button" />
          </div>

          <p>
            <span onClick={() => onClick("Home")} role="button">
              Home
            </span>
          </p>

          <p>
            <span onClick={() => onClick("Top-up")} role="button">
              Top-up Wallet
            </span>{" "}
          </p>
          <p>
            <span onClick={() => onClick("Profile")} role="button">
              My Profile
            </span>
          </p>
          <p>
            <span onClick={() => onClick("Transactions")} role="button">
              Transactions
            </span>
          </p>
          <p>
            <span onClick={() => onClick("Change Password")} role="button">
              Change Password
            </span>
          </p>
          <p>
            <span onClick={() => onClick("Logout")} role="button">
              Logout
            </span>
          </p>
        </StyledSideMenu>
      </Modal>
      <TopUpWallet visible={visibleT} handleCancel={handleCancelT} />
      <ChangePassword visible={visibleC} handleCancel={handleCancelC} />
      {isSuccess && (
        <MyProfile visible={visibleP} handleCancel={handleCancelP} />
      )}
    </>
  );
}
