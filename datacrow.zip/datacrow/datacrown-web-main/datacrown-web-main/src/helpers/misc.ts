"use client";

import { IMAGES } from "@/constant";

const misc = {
  validateAcctNo: function () {
    return new RegExp(/^(0|\d{10})$/);
  },
  validateAmount: function () {
    return new RegExp(/^([5-9]\d|[1-9]\d{2,})$/);
  },

  ucfirst: function (text: string) {
    text = text.substring(0, 1);
    return text.toUpperCase();
  },

  shortenText: function (text: string, max = 30) {
    if (!text) {
      text = "---";
    } else {
      text = text.length > max ? text.substring(0, max) + "..." : text;
    }
    return text;
  },

  errorMsg: function (err: any) {
    const errMsg =
      "error" in err ? err.error : JSON.parse(JSON.stringify(err.data)).message;
    return errMsg;
  },

  findNetworkImage: function (name: string) {
    switch (name.toLowerCase()) {
      case "mtn":
        return IMAGES.mtn;
      case "airtel":
        return IMAGES.airtel;
      case "glo":
        return IMAGES.glo;
      case "9mobile":
        return IMAGES.nMobile;
    }
  },
};

export default misc;
