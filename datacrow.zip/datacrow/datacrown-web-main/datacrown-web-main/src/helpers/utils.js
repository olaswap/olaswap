/**
 * @author
 * Akinyemi Tobiloba
 */
const util = {
  VALIDATE_URL: function (str) {
    const pattern = new RegExp(
      "^(https?:\\/\\/)?" + // protocol
        "((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|" + // domain name
        "((\\d{1,3}\\.){3}\\d{1,3}))" + // OR ip (v4) address
        "(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*" + // port and path
        "(\\?[;&a-z\\d%_.~+=-]*)?" + // query str
        "(\\#[-a-z\\d_]*)?$",
      "i"
    ); // fragment locator
    return !!pattern.test(str);
  },

  VALIDATE_EMAIL: function (email) {
    return String(email)
      .toLowerCase()
      .match(
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      );
  },

  phoneRegExp: function () {
    return /^[0][1-9]\d{9}$|^[1-9]\d{9}$/g;
  },

  VALIDATE_MOBILE: function (str) {
    return this.phoneRegExp().test(str);
  },

  numberFormat: function (number, decimals, dec_point, thousands_sep) {
    var n = !isFinite(+number) ? 0 : +number,
      prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
      sep = typeof thousands_sep === "undefined" ? "," : thousands_sep,
      dec = typeof dec_point === "undefined" ? "." : dec_point,
      toFixedFix = function (n, prec) {
        // Fix for IE parseFloat(0.55).toFixed(0) = 0;
        var k = Math.pow(10, prec);
        return Math.round(n * k) / k;
      },
      s = (prec ? toFixedFix(n, prec) : Math.round(n)).toString().split(".");
    if (s[0].length > 3) {
      s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    }
    if ((s[1] || "").length < prec) {
      s[1] = s[1] || "";
      s[1] += new Array(prec - s[1].length + 1).join("0");
    }
    return s.join(dec);
  },

  formatDate: function (dateString) {
    const dt = new Date(dateString);

    let day = dt.getDate();
    day = day < 10 ? "0" + day : day;

    let month = dt.getMonth();
    month = month < 10 ? "0" + month : month;
    let year = dt.getFullYear();
    year = year.toString().substring(2, 4);

    return `${day}/${month}/${year}`;
  },

  formatTime: function (dateString) {
    const date = new Date(dateString);
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? "0" + minutes : minutes;
    var strTime = hours + ":" + minutes + " " + ampm;
    return strTime;
  },

  setItem: function (key, value, json = false) {
    try {
      if (json) localStorage.setItem(key, JSON.stringify(value));
      else localStorage.setItem(key, value);
    } catch {
      return false;
    }
  },

  getItem: function (key, json = false) {
    try {
      if (json) return JSON.parse(localStorage.getItem(key));
      else return localStorage.getItem(key);
    } catch {
      return false;
    }
  },

  errorFormat: function (isError, error) {
    if (isError) {
      if ("status" in error) {
        let errMsg = "";

        if ("error" in error || "data" in error) {
          errMsg = error.status;
        } else {
          errMsg = error.originalStatus;
        }
        return errMsg;
      } else {
        if (error?.status) {
          return error.status;
        } else {
          return error.message;
        }
      }
    }
  },

  fectchError: function (isError, error) {
    let value = this.errorFormat(isError, error);
    value = value === "FETCH_ERROR" ? 1 : value;

    switch (value) {
      case 404:
        return 404;
      case 500:
        return 500;
      case 1:
        return 1;
      default:
        return 0;
    }
  },

  wordEllipsis: function (text, length = 20) {
    return text.length > length ? text.substring(0, length) + "..." : text;
  },

  capitalize: function (str) {
    var splitStr = str.toLowerCase().split(" ");
    for (var i = 0; i < splitStr.length; i++) {
      splitStr[i] =
        splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    return splitStr.join(" ");
  },
  ucfirst: function (text) {
    if (!text) {
      return "";
    }

    return `${text.substring(0, 1).toUpperCase()}${text.substring(
      1,
      text.length
    )}`;
  },
  requestError: function (error) {
    console.log(error);
  },

  weekDay: function (day) {
    const days = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];
    return days[day];
  },

  getNth: function (day) {
    switch (day) {
      case "1":
      case "21":
      case "31":
        return "st";
      case "2":
      case "22":
        return "nd";
      case "3":
      case "23":
        return "rd";
      default:
        return "th";
    }
  },
  replaceEmailWithStar: function (text) {
    text = text.split("@");
    const s = text[0].substring(0, 4);
    return `${s}***@${text[1]}`;
  },
};

export default util;
