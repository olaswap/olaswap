import {
  getCookie,
  setCookie,
  deleteCookie as removeCookie,
} from "cookies-next";
const DATA_PREFIX = "nasobet-v2::";

export function saveItem(key: string, value: any) {
  if (typeof window === "undefined") {
    return;
  }

  const data = typeof value === "string" ? value : JSON.stringify(value);
  localStorage.setItem(`${DATA_PREFIX}${key}`, data);
}

export function getItem(key: string) {
  if (typeof window === "undefined") {
    return null;
  }

  const value = localStorage.getItem(`${DATA_PREFIX}${key}`);
  const data =
    typeof value === "string" ? value : JSON.parse(JSON.stringify(value));
  return data ? data : null;
}

export function setAuthCookie(props: {
  expireAt: number;
  accessToken: string;
}) {
  const { expireAt, accessToken } = props;
  setCookie("accessToken", accessToken, {
    maxAge: expireAt,
    path: "/",
  });
}

export function getAuthCookie() {
  const cookie = getCookie("accessToken");
  if (!cookie) return undefined;
  return cookie;
}

export function deleteCookie(name: string) {
  removeCookie(name, {
    path: "/",
  });
}

export const months = [
  {
    name: "January",
    number: "01",
  },
  {
    name: "February",
    number: "02",
  },
  {
    name: "March",
    number: "03",
  },
  {
    name: "April",
    number: "04",
  },
  {
    name: "May",
    number: "05",
  },
  {
    name: "June",
    number: "06",
  },
  {
    name: "July",
    number: "07",
  },
  {
    name: "August",
    number: "08",
  },
  {
    name: "September",
    number: "09",
  },
  {
    name: "October",
    number: "10",
  },
  {
    name: "November",
    number: "11",
  },
  {
    name: "December",
    number: "12",
  },
];
