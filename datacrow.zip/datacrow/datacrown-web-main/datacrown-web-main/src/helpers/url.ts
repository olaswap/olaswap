export const LOGIN = "users/auth";
export const REGISTER = "users";
export const FORGOT_PASSWORD = "users/forgot-password";
export const RESET_PASSWORD = "users/reset-password";
export const SEND_OTP = "users/generate-otp";

// user

export const EDIT_PROFILE = "users";
export const PROFILE = "users/profile";
export const CONFIRM_EMAIL = "users/confirm-email";
export const CHANGE_PASSWORD = "users/change-password";
export const FUND_WALLET = "users/change-password";
export const BUY_SUBSCRIPTION = "users/change-password";
export const INITIALIZE_PAYMENT = "transactions/initialize";
export const TRANSACTIONS = "transactions/user";

//service
export const DATA_PLANS = "transactions/plans";
export const BUY_DATA = "transactions/buy-data";
export const BUY_AIRTIME = "transactions/buy-airtime";
