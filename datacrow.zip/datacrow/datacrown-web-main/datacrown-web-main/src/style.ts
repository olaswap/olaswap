import styled from "styled-components";
export const StyledHome = styled.section`
  margin-top: 80px;

  @media (min-width: 768px) {
    padding: 20px 50px;
  }
  .hero-section {
    margin-bottom: 50px;

    .content {
      margin-top: 80px;

      @media (max-width: 768px) {
        margin-top: 0;
      }

      h1 {
        color: var(--black-color);
        font-weight: 600;
        font-size: 40px;
        margin-bottom: 20px;

        @media (max-width: 768px) {
          font-weight: 600;
          font-size: 40px;
          margin-top: 30px;
          margin-bottom: 15px;
        }
      }
      p {
        font-size: 20px;
        font-weight: 500;
        color: var(--black-color);

        @media (max-width: 768px) {
          font-size: 17px;
        }
      }
    }

    .img-container {
      text-align: right;
      margin-right: 50px;

      @media (max-width: 768px) {
        // display: none;
      }
    }
  }

  .action-buttons {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;

    div {
      flex: 1 0 calc(50% - 20px);
      margin: 10px;
      text-align: center;
      align-self: center;
      p {
        font-size: 17px;
        font-weight: 600;
        color: var(--black-color);
        margin-top: 15px;

        @media (max-width: 768px) {
          font-weight: 600;
          font-size: 13px;
        }
      }

      svg {
        font-size: 100px;
        color: var(--white-color);
        background-color: var(--primary-color);
        padding: 30px;
        border-radius: 100px;

        @media (max-width: 768px) {
          font-size: 50px;
          padding: 15px;
        }
      }
    }
  }

  .wallet-balance {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: var(--white-color);
    padding: 20px;
    border: 1px solid var(--border-color);
    margin-bottom: 70px;

    @media (max-width: 768px) {
      padding: 15px 20px;
    }

    h5 {
      font-size: 25px;
      font-weight: 600;
      color: var(--black-color);

      @media (max-width: 768px) {
        font-size: 18px;
      }
    }
    p {
      font-size: 15px;
      font-weight: 500;
      color: var(--black-color);
      margin: 0;
    }

    button {
      border: 1px solid;
      padding: 10px 15px;
      font-weight: 500;
      font-size: 17px;
      border-radius: 15px;
      color: var(--white-color);
      background-color: var(--primary-color);

      @media (max-width: 768px) {
        padding: 7px 15px;
        border-radius: 10px;
        font-size: 14px;
      }
    }
  }
`;
