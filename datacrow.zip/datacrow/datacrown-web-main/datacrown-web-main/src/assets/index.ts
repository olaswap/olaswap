/* eslint-disable import/no-anonymous-default-export */
export const logo = require("./logo.png");
export const heroImage = require("./hero-img.png");

// network icons
export const nMobile = require("./9mobile.png");
export const airtel = require("./airtel.png");
export const mtn = require("./mtn.png");
export const glo = require("./glo.png");
export const bankIcon = require("./bank.png");

export default {
  logo,
  heroImage,
  nMobile,
  airtel,
  mtn,
  glo,
  bankIcon,
};
