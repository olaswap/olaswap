export default {
  admin: 'administrators',
  histories: 'histories',
  temps: 'temps',
  users: 'users',
  wallets: 'wallets',
};
