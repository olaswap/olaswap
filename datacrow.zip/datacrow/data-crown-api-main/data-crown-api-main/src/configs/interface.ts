import { TransactionTypes } from './enums';
import { OTPType, TransactionStatus } from './type';

export declare interface EmailConfig {
  email: string;
  firstName?: string;
  lastName?: string;
  username?: string;
}

export declare interface MailSenderOptions {
  subject: string;
  message: string;
}

export declare interface TransactionData {
  amount: number;
  id?: number;
  charge?: number;
  accessCode?: string;
  type: 'airtime' | 'data' | 'bill' | 'credit' | 'debit';
  provider?: string;
  reference?: string;
  url?: string;
  accountName?: string;
  accountNumber?: string;
  bankCode?: string | number;
  bankName?: string;
}

export declare interface ITemp {
  id?: number;
  registrationUuid: string;
  tokenValue: string;
  reason: OTPType;
  isUsed: boolean;
  createdAt: string | Date;
  expiredAt: string | Date;
}

export declare interface IAdministrator {
  id?: number;
  registrationUuid: string;
  email: string;
  password: string;
  createdAt?: string;
  updatedAt?: string;
}

export declare interface IAccount {
  id?: number;
  accountUuid: string;
  registrationUuid: string;
  accountNumber: string;
  accountName: string;
  bankName: string;
  bankCode: string;
  createdAt?: string | Date | null;
  updatedAt?: string | Date | null;
}

export declare interface IHistory {
  id?: number;
  transactionReference: string;
  registrationUuid: string;
  transactionType: TransactionTypes;
  amount: number;
  data: TransactionData;
  status: TransactionStatus;
  createdAt: string | Date;
  updatedAt?: string | Date;
}

export declare interface IUser {
  id?: number;
  registrationUuid: string;
  firstName?: string;
  lastName?: string;
  email: string;
  referralCode: string;
  password?: string;
  emailConfirmed?: boolean;
  balance: number;
  createdAt?: string | Date;
  updatedAt?: string | Date | null;
}

export declare interface IWallet {
  id?: number;
  walletUuid: string;
  registrationUuid: string;
  accountNumber: string;
  accountName: string;
  bankName: string;
  bankCode: string;
  createdAt?: string | Date;
  updatedAt?: string | Date;
}

export declare interface IPlan {
  amount: number;
  id: number;
  networkId: number;
  network: string;
  validity: string;
  plan: string;
  type?: string;
}

export declare interface INetworkPlans{
  mtn: IPlan[];
  glo: IPlan[];
  airtel: IPlan[];
  '9mobile': IPlan[];
}
