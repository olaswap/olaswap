/* eslint-disable no-unused-vars */

export enum TransactionTypes {
  credit = 'credit',
  debit = 'debit',
}
