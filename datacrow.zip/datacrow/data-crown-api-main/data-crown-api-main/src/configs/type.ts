export type LogLevel =
  | 'silent'
  | 'error'
  | 'warn'
  | 'info'
  | 'http'
  | 'verbose'
  | 'debug'
  | 'silly';
export type Environment = 'development' | 'production' | 'staging';
export type OTPType = 'EMAIL_VERIFICATION' | 'FORGOT_PASSWORD';

export type TransactionStatus = 'pending' | 'success' | 'failed';

export type Action = 'APPROVE' | 'CANCEL' | 'RESEND';
