export const allowedOrigins = [
  'https://sandbox.dcr.com.ng',
  'https://dcr.com.ng',
  'https://web.dcr.com.ng',
  'https://dev-app.dcr.com.ng',
  'https://pay.dcr.com.ng',
  // 'admin.socket.io',
];

export const exposedHeaders = [
  'Content-Length',
  'Content-Range',
  'Content-Type',
  'ETag',
  'Last-Modified',
  'Link',
  'Location',
  'Refresh',
  'Retry-After',
  'Set-Cookie',
  'Vary',
  'WWW-Authenticate',
];

export const networks = ['MTN', 'GLO', '9MOBILE', 'AIRTEL'];
