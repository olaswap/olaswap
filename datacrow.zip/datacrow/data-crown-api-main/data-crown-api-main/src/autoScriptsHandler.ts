import autoTransactionCancelHandler from '@/Handlers/autoTransactionCancelHandler';
import { CronJob } from 'cron';

class CronRunner {
  constructor() {
    try {
      // Run every 30mins
      new CronJob('*/30 * * * *', autoTransactionCancelHandler).start();
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('ERROR::', err);
    }
  }
}

export default new CronRunner();
