import crypto from 'crypto';

import AppError from '@/Helpers/AppError';
import logger from '@/Helpers/logger';
import messages from '@/Helpers/messages';
import { getFileContent, isRestricted, recordExists } from '@/Helpers/util';
import { MailSender } from '@/Services/index';
import config from '@/configs/index';
import { IUser } from '@/configs/interface';

const nairaSymbol = '₦';

function shuffle(param: any[]) {
  const params = [];

  const arr = [...param];

  for (let i = 0; i < arr.length; i++) {
    // const item = param[i];
    const index = chooseIndex(param.length);
    params.push(param[index]);
    param.splice(index, 1);
  }

  return params;
  // return param
  //   .map((a) => ({ sort: Math.random(), value: a }))
  //   .sort((a, b) => a.sort - b.sort)
  //   .map((a) => a.value);
}

async function isSufficientBalance(registrationUuid: string, amount: number) {
  // Fetch user
  const profile = await fetchUser(registrationUuid);

  const balance = profile!.balance ? profile!.balance.toNumber() : 0;

  // Check user's balance
  if (balance < Number(amount) + 1) {
    throw new AppError(messages.ERR_BALANCE_INSUFFICIENT, 400);
  }

  return true;
}

async function debitUser(
  registrationUuid: string,
  amount: number,
): Promise<void> {
  // Initialize repositories
  const userRepository = config.db.user;

  const profile = await fetchUser(registrationUuid);

  // Deduct fund
  profile!.balance = profile!.balance!.minus(amount);
  await userRepository.update({
    data: {
      balance: profile!.balance,
    },
    where: {
      registrationUuid,
    },
  });
}

/**
 * Validate user amount
 * @param {number} amount
 * @return {boolean}
 */
function isValidAmount(amount: number) {
  if (isNaN(amount)) {
    throw new AppError(messages.ERR_INVALID_AMOUNT, 400);
  }

  if (Number(amount) < 50) {
    throw new AppError(messages.ERR_LESS_AMOUNT, 400);
  }
  return true;
}

function isValidNetwork(network: string) {
  const networks = ['MTN', 'AIRTEL', 'GLO', '9MOBILE'];
  if (!networks.includes(network.toUpperCase())) {
    throw new AppError('Invalid network provider.', 400);
  }

  return true;
}

interface EmailNotificationOptions {
  registrationUuid?: string;
  recipient?: string;
  subject: string;
  message?: string;
  path?: string;
  replace?: { key: string; val: string | number }[];
}
async function sendEmailNotification(opt: EmailNotificationOptions) {
  // Instantiate database models
  const userRepository = config.db.user;

  // Fetch user
  let profile: null | IUser;
  if (opt.registrationUuid) {
    profile = (await userRepository.findFirst({
      where: {
        registrationUuid: opt.registrationUuid,
      },
    })) as any;
    if (!profile) return;
  }

  opt.message = opt.message == null ? getFileContent(opt.path!) : opt.message;
  let content = opt.message;
  if (!opt.message) {
    content = getFileContent('index.html');
  }
  const style = getFileContent('css/style.css');
  content = content.replace('[[style]]', style);
  const username = profile! && profile.firstName ? profile.firstName : 'User';

  const baseUrl = 'https://app.dcr.com.ng';

  content = content.replace(/\[\[content\]\]/g, opt.message);
  if (opt.replace!) {
    for (let i = 0; i < opt.replace!.length; i++) {
      const item = opt.replace![i];
      // const replace = `/${item.key}/`;
      // const reg = new RegExp(replace, 'g');
      content = content.replace(item.key, item.val.toString());
    }
  }

  content = content.replace(/\[\[baseUrl\]\]/g, baseUrl);
  content = content.replace(/\[\[username\]\]/g, username);
  const email = (profile! ? profile!.email : opt.recipient) as string;
  const firstName = profile! && profile.firstName ? profile.firstName : null;
  const lastName = profile! && profile.lastName ? profile.lastName : null;
  await new MailSender({
    email,
    firstName: firstName!,
    username,
    lastName: lastName!,
  }).sendMail({ message: content, subject: opt.subject });
  logger.info('Notification:: Email sent successfully.');
}

function chooseIndex(max: number): number {
  return Math.floor(Math.random() * max);
}

function sortByAsc(items: any[], property: string): any[] {
  for (let i = 0; i < items.length; i++) {
    for (let j = 0; j < items.length - i - 1; j++) {
      if (items[j][property] > items[j + 1][property]) {
        [items[j], items[j + 1]] = [items[j + 1], items[j]];
      }
    }
  }
  return items;
}

function sortByDsc(items: any[], property: string): any[] {
  for (let i = 0; i < items.length; i++) {
    for (let j = 0; j < items.length - i - 1; j++) {
      if (items[j + 1][property] > items[j][property]) {
        [items[j + 1], items[j]] = [items[j], items[j + 1]];
      }
    }
  }
  return items;
}

const algorithm = 'aes-256-cbc';
function encryptData(payload: any, key: string): string {
  const iv = crypto
    .createHash('sha256')
    .update(key)
    .digest('hex')
    .substring(0, 16);
  const derivedKey = crypto
    .createHash('sha256')
    .update(key)
    .digest('hex')
    .substring(0, 32);
  const cipher = crypto.createCipheriv(algorithm, derivedKey, iv);
  const encryptedText =
    cipher.update(payload, 'utf8', 'hex') + cipher.final('hex');
  return encryptedText;
}

function decryptData(encryptedText: string, key: string): string {
  const iv = crypto
    .createHash('sha256')
    .update(key)
    .digest('hex')
    .substring(0, 16);
  const derivedKey = crypto
    .createHash('sha256')
    .update(key)
    .digest('hex')
    .substring(0, 32);
  const decipher = crypto.createDecipheriv(algorithm, derivedKey, iv);
  const decryptData =
    decipher.update(encryptedText, 'hex', 'utf8') + decipher.final('utf8');
  return decryptData;
}

export async function fetchUser(registrationUuid: string) {
  // Instantiate database
  const userRepository = config.db.user;

  // Fetch user's record
  const profile = await userRepository.findFirst({
    where: {
      registrationUuid,
    },
  });
  recordExists(profile, 'Profile');
  isRestricted(profile);

  return profile;
}

export {
  chooseIndex,
  debitUser,
  decryptData,
  encryptData,
  isSufficientBalance,
  isValidAmount,
  isValidNetwork,
  nairaSymbol,
  sendEmailNotification,
  shuffle,
  sortByAsc,
  sortByDsc
};
