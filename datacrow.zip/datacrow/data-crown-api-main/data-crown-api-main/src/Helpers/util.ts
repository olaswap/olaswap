import bcrypt from 'bcrypt';
import crypto from 'crypto';
import fs from 'fs';
import jwt from 'jsonwebtoken';
import libPhoneNumberJs from 'libphonenumber-js';
import ms from 'ms';
import path from 'path';

import AppError from '@/Helpers/AppError';
import messages from '@/Helpers/messages';
import config from '@/configs/index';
import { decryptData } from './misc';

function handleApiError(err: any) {
  if (err.response && err.response.data) {
    throw new AppError(
      err.response.data.message || err.message,
      err.response.status || 500,
    );
  } else if (err.request) {
    throw new AppError(err.message || 'Unable to complete request.', 500);
  } else {
    throw new AppError(err.message, 500);
  }
}

function jwtDecoder(payload: string): any {
  return jwt.verify(payload, config.jwt.key, {
    ignoreExpiration: false,
  });
}

/**
 * JWT ==> Json Web Token
 *
 * Convert payload to JWT string
 * @param {any} payload - Payload to encode
 * @return {object} - Encoded data
 */
function jwtEncoder(payload: any) {
  return {
    accessToken: jwt.sign(payload, config.jwt.key, {
      expiresIn: config.jwt.ttl,
    }),
    expiresAt: new Date().getTime() + ms(config.jwt.ttl),
  };
}

/**
 * This function is use to remove html tags= require(string
 *
 * @param {string} str   String to sanitize
 * @return {string}  String converted
 */
function stripTags(str: string): string {
  return str.toString().replace(/(<([^>]+)>)/gi, '');
}

function inputValidation(input: string): string {
  const word = stripTags(input.toString());
  return word.trim();
}

function shuffle(str: string | string[]) {
  const a = Array.isArray(str) ? str : str.split('');
  const n = a.length;

  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
  }
  return a.join('');
}

function isValidPhoneNumber(phoneNumber: string) {
  const result = libPhoneNumberJs(phoneNumber, 'NG');
  // validate phone number
  if (!result || !result.isValid()) {
    throw new AppError(messages.INVALID_PHONE, 400);
  }
  // phoneNumber = result.number;
  return phoneNumber;
}

function capitalize(str: string) {
  const strArr = str.split(' ');
  return strArr.reduce((prev, curr) => {
    return `${prev} ${curr.charAt(0).toUpperCase()}${curr.slice(1)}`.trim();
  }, '');
}

function hasWhiteSpace(str: string, field = 'Username') {
  if (/\s/g.test(str)) {
    throw new AppError(`${field} must not contain whitespace character`, 400);
  }
  return false;
}

function isValidEmail(email: string) {
  const re =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  if (!re.test(String(email).toLowerCase())) {
    throw new AppError(messages.ERR_INVALID_EMAIL, 400);
  }
  return true;
}

/**
 * Generate account default password
 * @return {string} password
 */
function generatePassword() {
  const seedValue = '012345689!@#$%^&*()_';
  let password = '';

  let count = 0;
  while (count < 10) {
    const index = Number(Number(Math.random() * 20).toFixed(0));
    password += seedValue[index];
    count++;
  }

  return password;
}

/**
 * Generate OTP digits
 * @param {number} length - Length of character to generate
 * @return {number}
 */
function generateOTP(length = 4) {
  const seedValue =
    '6780123456789123456789127801234567567891234567891278012344567891278012345675678912345018376107382918';
  let ud = '';

  let count = 0;
  while (count < length) {
    const index = Number(Number(Math.random() * 100).toFixed(0));
    ud += seedValue[index];
    count++;
  }

  return ud;
}

function generateReferralCode() {
  const seedValue = 'QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm';
  let ud = '';

  let count = 0;
  while (count < 6) {
    const index = Number(Number(Math.random() * 24).toFixed(0));
    ud += seedValue[index];
    count++;
  }

  return ud;
}

/**
 * Encrypt password
 * @param {string} plainPassword - Plain password
 * @return {string} - Encrypted password
 */
async function hashPassword(plainPassword: string) {
  return await bcrypt.hash(plainPassword, 10);
}

/**
 * Compare hashed password and plain password to check if correct
 * @param {string} plainPassword - Plain password to check
 * @param {string} hashedPassword - Hashed password to confirm
 * @param {string} key - Key for hashed password
 * @return {boolean}
 */
async function comparePassword(
  plainPassword: string,
  hashedPassword: string,
  key: string,
) {
  return plainPassword === decryptData(hashedPassword, key);
}

/**
 * Generate a token
 * @return {string} - Generated characters
 */
function createToken() {
  const resetToken = crypto.randomBytes(32).toString('hex');
  return crypto.createHash('sha256').update(resetToken).digest('hex');
}

/**
 * Check if data is set
 * @param {any} record - Data to check
 * @param {string} recordType - Type of record
 * @return {any}
 */
function recordExists(record: any, recordType = 'Record') {
  if (Array.isArray(record)) {
    record = record[0];
  }
  if (!record) {
    throw new AppError(
      messages.ERR_RECORD.replace(/Record/, inputValidation(recordType)),
      404,
    );
  }
  return true;
}

function getFileContent(fileName: string): string {
  const basePath = path.join(__dirname, '..', 'public');
  const contentPath = path.join(basePath, fileName);
  if (fs.existsSync(contentPath)) {
    return fs.readFileSync(contentPath, { encoding: 'utf-8' });
  }

  return fileName;
}

/**
 * To group array object by specified property
 *
 * @param {Array} objectArray - Array object
 * @param {string} property - Property to group with
 * @return {object}
 */
async function groupBy(objectArray: any[], property: string) {
  const acc: Array<any> = [];
  for (let i = 0; i < objectArray.length; i++) {
    const item = objectArray[i];

    let key = item[property];

    if (property === 'createdAt' && key) {
      const date = new Date(key).getDate();
      const month = new Date(key).getMonth() + 1;
      const year = new Date(key).getFullYear();
      key = `${date}-${month}-${year}`;
    }

    let index = acc.findIndex(function (itm: any) {
      return itm[property] === key;
    });

    // Add object to list for given key's value
    if (index < 0) {
      index = acc.length;
      const prop = new Map();
      prop.set(property, key);

      if (property === 'sessionUuid') {
        if (item.createdAt) prop.set('createdAt', item.createdAt);
        if (item.expiredAt) prop.set('expiredAt', item.expiredAt);
      }

      acc[index] = { ...Object.fromEntries(prop), items: [{ ...item }] };
    } else {
      acc[index].items.push(item);
    }
  }

  return acc;
}

/**
 * Check if user is restricted
 * @param {User | Administrator | null} user - User data
 * @return {boolean}
 */
function isRestricted(user: any) {
  if (user.disabled) {
    throw new AppError(messages.ERR_ACC_LOCKED, 401);
  }

  if (user.archived) {
    throw new AppError(messages.ERR_ACC_ARCHIVED, 401);
  }
  return false;
}

function isDisabled(user: any) {
  if (user.disabled) {
    throw new AppError(messages.ERR_ACC_DISABLED, 401);
  }
  return false;
}

function isLocked(user: any) {
  if (user.freezed) {
    throw new AppError(messages.ERR_ACC_LOCKED, 401);
  }
  return false;
}

async function validateAuthorization(authorizationHeader: string) {
  const authorizations = authorizationHeader!.split(' ');
  if (
    authorizations.length < 2 ||
    authorizations.length > 2 ||
    (String(authorizations[0]).toUpperCase() !== 'BEARER' &&
      String(authorizations[0]).toUpperCase() !== 'BASIC')
  ) {
    throw new AppError(messages.ACCESS_INV_ERR, 400);
  }

  const accessToken = String(authorizations[1]);
  if (String(authorizations[0]).toUpperCase() !== 'BEARER') {
    throw new AppError(messages.ACCESS_INV_ERR, 400);
  }

  const data: any = {};

  // Decode access token
  const decodedPayload = jwtDecoder(accessToken);

  // Instantiate database repositories
  const userRepository = config.db.user;
  const adminRepository = config.db.administrator;

  if (!decodedPayload.user.isAdmin) {
    // Fetch user's record
    const user = await userRepository.findFirst({
      where: {
        registrationUuid: decodedPayload.user.registrationUuid,
      },
    });
    recordExists(user, 'Account');
    isRestricted(user);

    Object.assign(data, { ...decodedPayload, env: config.environment });
  } else {
    const admin = await adminRepository.findFirst({
      where: {
        registrationUuid: decodedPayload.user.registrationUuid,
      },
    });
    recordExists(admin, 'Account');
    isRestricted(admin);
    Object.assign(data, {
      ...decodedPayload,
      env: config.environment,
    });
  }

  return data;
}

/**
 * Remove sensitive properties
 * @param user - User's record
 * @return {User | Administrator}
 */
function removeSensitiveData(user: any) {
  if (user.pin) delete user!.pin;
  delete user.password;
  delete user.id;
  return user;
}

/**
 * Delete file from a folder
 * @param {string} fileName - Name of file to delete
 * @param {string} folderName - Name of folder to delete file from
 * @return {boolean | void} - This will return true if successful otherwise false
 */
function deleteFile(fileName: string, folderName: string) {
  const filePath = path.join('protected', folderName, fileName);

  // Check if file exists
  if (fs.existsSync(filePath)) {
    // Delete file
    fs.unlinkSync(filePath);
    return true;
  }
}

/**
 *Check if array consists duplicate values
 * @param {any[]} arr - Array to check
 * @return {boolean}
 */
function hasDuplicates(arr: any[]) {
  const valuesSoFar = Object.create(null);
  for (let i = 0; i < arr.length; ++i) {
    const value = arr[i];
    if (value in valuesSoFar) {
      return true;
    }
    valuesSoFar[value] = true;
  }

  return false;
}

function generateReference(suffix: 'jtb' | 'ses' | 'trd' = 'jtb'): string {
  const reference = `${new Date().getTime().toString()}-${suffix}`;
  return reference;
}

export {
  capitalize,
  comparePassword,
  createToken,
  deleteFile,
  generateOTP,
  generatePassword,
  generateReference,
  generateReferralCode,
  getFileContent,
  groupBy,
  handleApiError,
  hasDuplicates,
  hashPassword,
  hasWhiteSpace,
  inputValidation,
  isDisabled,
  isValidPhoneNumber,
  isLocked,
  isRestricted,
  isValidEmail,
  jwtDecoder,
  jwtEncoder,
  recordExists,
  removeSensitiveData,
  shuffle,
  stripTags,
  validateAuthorization,
};
