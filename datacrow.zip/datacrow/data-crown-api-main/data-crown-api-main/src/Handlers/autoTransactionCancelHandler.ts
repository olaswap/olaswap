import config from '@/configs';
import ms from 'ms';

export default async function () {
  // Instantiate database
  const historyRepository = config.db.history;

  //  Fetch transactions
  const txs = await historyRepository.findMany({
    where: {
      status: 'pending',
    },
  });

  if (txs.length <= 0) return;

  for (let i = 0; i < txs.length; i++) {
    const tx = txs[i];
    const time = new Date().getTime() - new Date(tx.createdAt).getTime();

    if (time >= ms('30m')) {
      // await historyRepository.delete({ where: { id: tx.id } });
    }
  }
}
