import 'tsconfig-paths/register';
import config from '@/configs';
import Cache from '@/Helpers/Cache';
import logger from '@/Helpers/logger';
import 'dotenv/config';
import http from 'http';
import app from './app';
const PORT = config.app.port || 3300;
const HOST = config.app.host || 'localhost';

const server = http.createServer(app);

server.listen(PORT, async () => {
  logger.info(`App listening on: http://${HOST}:${PORT}`);
  await Cache.open().catch(console.log);
});

server.on('error', handleStartError);

// eslint-disable-next-line require-jsdoc
function handleStartError(err: Error) {
  console.log(err);
}

process.on('warning', (e) => console.warn(e));

// Handle unhandledRejection error
process.on('unhandledRejection', (err: Error) => {
  console.log(err);
  logger.info('UNHANDLED REJECTION. Shutting down...❌');
  // Close connection gracefully
  logger.exitOnError = true;
  server.close(() => {
    process.exit(1);
  });
});

// Handle uncaughtException error
process.on('uncaughtException', (err: Error) => {
  console.log(err);
  logger.info('UNCAUGHT EXCEPTION. Shutting down...❌');
  // Close connection gracefully
  logger.exitOnError = true;
  server.close(() => {
    process.exit(1);
  });
});
