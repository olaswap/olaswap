import compression from 'compression';
import cors from 'cors';
import express, { NextFunction, Request, Response } from 'express';
import helmet from 'helmet';
import hpp from 'hpp';
import morgan from 'morgan';
import 'reflect-metadata';

// eslint-disable-next-line no-unused-vars
import AppError from '@/Helpers/AppError';
import globalErrorHandler from '@/Middlewares/globalErrorHandler';
import rateLimitHandler from '@/Middlewares/rateLimitHandler';
import xssCleanHandler from '@/Middlewares/xssCleanHandler';
import config from '@/configs';
import { exposedHeaders } from '@/configs/constants';
import morganBody from 'morgan-body';
import routes from './Routes';
import './autoScriptsHandler';

const app = express();
app.disable('powered-by');
app.use(express.static('protected'));
app.use(express.static('protected/games/categories'));
app.use(express.static('protected/assets/icons'));
app.use(express.static('protected/games/flags'));
app.use(express.static('protected/games'));
app.use(express.static('protected/images'));
app.use(express.static('protected/assets'));
app.use(express.static('src/public/css'));

app.set('trust proxy', 1);

// Disconnect from database after request has been sent
app.use((req: Request, res: Response, next: NextFunction) => {
  res.on('finish', async () => {
    await config.db.$disconnect();
  });
  next();
});

config.basePath = __dirname;
if (config.morgan.logger) {
  app.use(
    morgan(':method :url :status :response-time ms - :res[content-length]'),
  );
}

if (config.morgan.body) {
  morganBody(app, {
    filterParameters: [
      'password',
      'currentPassword',
      'oldPassword',
      'newPassword',
    ],
  });
}

// Enable CORS ==> Cross Origin Resource Sharing
app.use(
  cors({
    origin: '*', // allowedOrigins,
    methods: ['POST', 'PUT', 'DELETE', 'GET'],
    exposedHeaders,
    optionsSuccessStatus: 200,
  }),
);

app.use(express.urlencoded({ extended: false }));
app.use(express.json({ limit: '4kb' }));

// Express rate limiter
app.use(rateLimitHandler);

// XSS clean
app.use(xssCleanHandler);

// Filter HTTP Headers
app.use(helmet());

// Prevent HTTP Parameter Pollution
app.use(hpp());

// Compress response middleware
app.use(compression());

// Endpoints goes here...
app.use('/api', routes);

// Page not found
app.use('*', (req: Request, res: Response, next: NextFunction) => {
  next(new AppError(`Can't find ${req.originalUrl} on this server!`, 404));
});

// Global error handler
app.use(globalErrorHandler);

export default app;
