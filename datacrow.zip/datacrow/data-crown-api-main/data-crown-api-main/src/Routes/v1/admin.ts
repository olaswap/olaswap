import changePasswordController from '@/Controllers/AdminControllers/changePasswordController';
import forgotPasswordController from '@/Controllers/AdminControllers/forgotPasswordController';
import loginController from '@/Controllers/AdminControllers/loginController';
import resetPasswordController from '@/Controllers/AdminControllers/resetPasswordController';
import authorizationHandler from '@/Middlewares/authorizationHandler';
import validateParamsHandler from '@/Middlewares/validateParamsHandler';
import express from 'express';

const router = express.Router();

router.post(
  '/auth',
  validateParamsHandler(['username', 'password']),
  loginController,
);

router.put(
  '/change-password',
  authorizationHandler,
  validateParamsHandler('user, currentPassword, password'),
  changePasswordController,
);

router.put(
  '/forgot-password',
  validateParamsHandler('email'),
  forgotPasswordController,
);

router.put(
  '/reset-password',
  validateParamsHandler('token, password'),
  resetPasswordController,
);

export default router;
