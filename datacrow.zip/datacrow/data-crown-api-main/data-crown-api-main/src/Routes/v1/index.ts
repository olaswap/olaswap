import express from 'express';
import admin from './admin';
import transaction from './transaction';
import user from './user';

const router = express.Router();

router.use('/administrations', admin);
router.use('/transactions', transaction);
router.use('/users', user);

export default router;
