import buyAirtimeController from '@/Controllers/BillsControllers/buyAirtimeController';
import buyDataController from '@/Controllers/BillsControllers/buyDataController';
import plansController from '@/Controllers/BillsControllers/plansController';
import fetchTransactionController from '@/Controllers/TransactionControllers/fetchTransactionController';
import fetchUserTransactionsController from '@/Controllers/TransactionControllers/fetchUserTransactionsController';
import fetchUsersTransactionsController from '@/Controllers/TransactionControllers/fetchUsersTransactionsController';
import initializeTransactionController from '@/Controllers/TransactionControllers/initializeTransactionController';
import paystackWebhookController from '@/Controllers/TransactionControllers/paystackWebhookController';
import authorizationHandler from '@/Middlewares/authorizationHandler';
import validateParamsHandler from '@/Middlewares/validateParamsHandler';
import express from 'express';

const router = express.Router();

router.post(
  '/initialize',
  authorizationHandler,
  validateParamsHandler(['amount', 'user']),
  initializeTransactionController,
);

router.post(
  '/buy-airtime',
  authorizationHandler,
  validateParamsHandler(['amount', 'phoneNumber', 'network', 'user']),
  buyAirtimeController,
);

router.post(
  '/buy-data',
  authorizationHandler,
  validateParamsHandler(['amount', 'phoneNumber', 'network', 'planId', 'plan', 'user']),
  buyDataController,
);

router.get(
  '/plans',
  plansController,
);

router.get(
  '/user/:registrationUuid?',
  authorizationHandler,
  validateParamsHandler('user'),
  fetchUserTransactionsController,
);

router.get(
  '/:transactionReference',
  authorizationHandler,
  validateParamsHandler('user'),
  fetchTransactionController,
);

router.post(
  '/paystack-webhook',
  validateParamsHandler('data, event'),
  paystackWebhookController,
);

router.get('/', authorizationHandler, fetchUsersTransactionsController);

export default router;
