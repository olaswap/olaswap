import changePasswordController from '@/Controllers/UserControllers/changePasswordController';
import confirmEmailController from '@/Controllers/UserControllers/confirmEmailController';
import editProfileController from '@/Controllers/UserControllers/editProfileController';
import forgotPasswordController from '@/Controllers/UserControllers/forgotPasswordController';
import generateOtpController from '@/Controllers/UserControllers/generateOtpController';
import loginController from '@/Controllers/UserControllers/loginController';
import registerController from '@/Controllers/UserControllers/registerController';
import resetPasswordController from '@/Controllers/UserControllers/resetPasswordController';
import userController from '@/Controllers/UserControllers/userController';
import usersController from '@/Controllers/UserControllers/usersController';
import authorizationHandler from '@/Middlewares/authorizationHandler';
import validateParamsHandler from '@/Middlewares/validateParamsHandler';
import express from 'express';

const router = express.Router();

router.post('/', validateParamsHandler('email, password'), registerController);

router.get(
  '/profile/:registrationUuid?',
  authorizationHandler,
  validateParamsHandler('user'),
  userController,
);

router.get(
  '/',
  authorizationHandler,
  validateParamsHandler('user'),
  usersController,
);

router.put(
  '/',
  authorizationHandler,
  validateParamsHandler('user'),
  editProfileController,
);

router.post('/auth', validateParamsHandler('email, password'), loginController);

router.post(
  '/confirm-email',
  validateParamsHandler('token'),
  confirmEmailController,
);

router.post(
  '/forgot-password',
  validateParamsHandler('email'),
  forgotPasswordController,
);

router.post(
  '/generate-otp',
  validateParamsHandler('type'),
  generateOtpController,
);

router.put(
  '/change-password',
  authorizationHandler,
  validateParamsHandler('user, currentPassword, newPassword'),
  changePasswordController,
);

router.put(
  '/reset-password',
  validateParamsHandler('token, password'),
  resetPasswordController,
);

export default router;
