import config from '@/configs';
import { ITemp } from '@/configs/interface';
import { OTPType } from '@/configs/type';
import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import { sendEmailNotification } from '@/Helpers/misc';
import { generateOTP, isDisabled, recordExists } from '@/Helpers/util';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    const { email, type }: any = {
      ...req.body,
      ...req.query,
      ...req.params,
    };

    let action: OTPType;
    switch (type as OTPType) {
    case 'EMAIL_VERIFICATION':
      if (!email) {
        return next(new AppError('Email address is required.', 400));
      }
      action = 'EMAIL_VERIFICATION';
      break;

    default:
      return next(new AppError(messages.ERR_OPERATION_NOT_ALLOWED, 401));
    }

    // Initialize User, Token and Trail repositories
    const userRepository = config.db.user;
    const tempRepository = config.db.temp;

    // Fetch user's record
    const profile = await userRepository.findFirst({
      where: {
        email,
      },
    });
    recordExists(profile);
    isDisabled(profile);

    // Check if email is already confirmed
    if (profile!.emailConfirmed && action === 'EMAIL_VERIFICATION') {
      return next(new AppError(messages.EMAIL_ALREADY_CONFIRMED, 401));
    }

    // Check if token exists
    const tokenData = await tempRepository.findFirst({
      where: {
        registrationUuid: profile!.registrationUuid,
        reason: action,
      },
    });

    // Set token object properties
    const temp: ITemp = {
      id: tokenData?.id,
      registrationUuid: profile!.registrationUuid,
      tokenValue: generateOTP(4), // await createToken(),
      reason: action,
      isUsed: false,
      createdAt: new Date().toISOString(),
      expiredAt: new Date(
        new Date().setTime(new Date().getTime() + 30 * 60 * 1000),
      ).toISOString(),
    };
    await tempRepository.upsert({
      where: {
        id: temp.id,
      },
      create: temp,
      update: temp,
    });

    if (action === 'EMAIL_VERIFICATION') {
      // Send account verification email
      sendEmailNotification({
        registrationUuid: profile!.registrationUuid,
        subject: 'Action Required: Email Verification',
        message: `Enter this OTP to verify your account: ${temp.tokenValue}`,
      });
    }

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Operation successful.',
    });
  },
);
