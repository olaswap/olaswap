import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import { sendEmailNotification } from '@/Helpers/misc';
import {
  comparePassword,
  generateOTP,
  isDisabled,
  jwtEncoder,
  removeSensitiveData,
} from '@/Helpers/util';
import config from '@/configs/index';
import { ITemp } from '@/configs/interface';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    const { email, password } = req.body;

    // Instantiate database
    const userRepository = config.db.user;
    const tempRepository = config.db.temp;

    // Fetch user's record
    const profile = await userRepository.findFirst({
      where: {
        email,
      },
    });

    // Check if profile found
    if (!profile || !profile.password) {
      return next(new AppError(messages.ERR_LOGIN, 401));
    }

    // Check if password is correct
    const isConfirmed = await comparePassword(
      password,
      profile.password as string,
      profile.registrationUuid,
    );
    if (!isConfirmed) {
      return next(new AppError(messages.ERR_LOGIN, 400));
    }

    // Check if user is restricted
    isDisabled(profile);

    if (!profile.emailConfirmed) {
      const temp = await tempRepository.findFirst({
        where: {
          registrationUuid: profile!.registrationUuid,
          reason: 'EMAIL_VERIFICATION',
        },
      });
      // Set token object properties
      const temp2: ITemp = {
        ...temp,
        registrationUuid: profile.registrationUuid,
        tokenValue: generateOTP(4),
        reason: 'EMAIL_VERIFICATION',
        isUsed: false,
        createdAt: new Date().toISOString(),
        expiredAt: new Date(
          new Date().setTime(new Date().getTime() + 30 * 60 * 1000),
        ).toISOString(),
      };
      if (temp) {
        await tempRepository.update({
          where: {
            id: temp2.id,
          },
          data: temp2,
        });
      } else {
        await tempRepository.create({
          data: temp2,
        });
      }

      // Send account verification email
      sendEmailNotification({
        message: `Enter this OTP to verify your account: ${temp2.tokenValue}`,
        registrationUuid: profile!.registrationUuid,
        subject: 'Verify Your Email Address',
      });

      return next(new AppError(messages.VERIFY_EMAIL_TO_CONTINUE, 400));
    }

    // Generate access token
    const accessToken = jwtEncoder({
      user: {
        registrationUuid: profile.registrationUuid,
        isAdmin: false,
      },
    });

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Authenticated.',
      data: {
        ...removeSensitiveData(profile),
        ...accessToken,
      },
    });
  },
);
