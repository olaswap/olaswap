import catchAsync from '@/Helpers/catchAsync';
import { isDisabled, recordExists, removeSensitiveData } from '@/Helpers/util';
import config from '@/configs';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(async function (
  req: Request,
  res: Response,
  next: NextFunction,
) {
  let { registrationUuid, user }: any = { ...req.body, ...req.params };

  if (!registrationUuid) {
    registrationUuid = user.registrationUuid;
  }

  // Initialize User and Account repositories
  const userRepository = config.db.user;

  // Fetch user's record
  const profile = await userRepository.findFirst({
    include: {
      wallet: true,
    },
    where: {
      registrationUuid,
    },
  });
  recordExists(profile);
  if (!user.isAdmin) {
    isDisabled(profile);
  }

  // Send response to client
  return res.status(200).json({
    status: 'success',
    message: 'Record retrieved successfully.',
    data: removeSensitiveData(profile),
  });
});
