import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import { encryptData, sendEmailNotification } from '@/Helpers/misc';
import { comparePassword, isDisabled } from '@/Helpers/util';
import config from '@/configs';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    let { registrationUuid, currentPassword, newPassword, user } = req.body;

    if (!registrationUuid) {
      registrationUuid = user.registrationUuid;
    }

    // Initialize User and Trail repositories
    const userRepository = config.db.user;

    // Fetch user's record
    const profile = await userRepository.findFirst({
      where: {
        registrationUuid,
      },
    });

    // Check user restriction
    isDisabled(profile);

    // Check if current password is correct
    const isCorrect = await comparePassword(
      currentPassword,
      profile!.password!,
      registrationUuid,
    );
    if (!isCorrect) {
      return next(new AppError(messages.ERR_CUR_PASSWORD, 400));
    }

    // Encrypt new password
    profile!.password = encryptData(newPassword, profile!.registrationUuid);
    profile!.updatedAt = new Date();

    // Update record
    await userRepository.update({
      where: {
        registrationUuid,
      },
      data: profile!,
    });

    // Send email to user
    sendEmailNotification({
      message: 'You have successfully changed your password.',
      registrationUuid,
      subject: 'Password Changed Successfully',
    });

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Password changed.',
    });
  },
);
