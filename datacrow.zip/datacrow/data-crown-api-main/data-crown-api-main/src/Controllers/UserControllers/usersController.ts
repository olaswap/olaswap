import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import config from '@/configs';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(async function (
  req: Request,
  res: Response,
  next: NextFunction,
) {
  const { user }: any = { ...req.body, ...req.params };

  if (!user.isAdmin) {
    return next(new AppError(messages.ERR_OPERATION_NOT_ALLOWED, 401));
  }

  // Instantiate database
  const userRepository = config.db.user;

  // Fetch user's record
  const users = await userRepository.findMany();
  if (users.length <= 0) {
    return next(new AppError(messages.ERR_RECORD, 404));
  }

  // Send response to client
  return res.status(200).json({
    status: 'success',
    message: 'Record retrieved.',
    data: users,
  });
});
