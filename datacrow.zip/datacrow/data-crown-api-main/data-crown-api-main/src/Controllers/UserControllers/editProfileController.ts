import config from '@/configs';
import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import { isDisabled, isValidEmail, recordExists } from '@/Helpers/util';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    let { registrationUuid, email, firstName, lastName, phoneNumber, user } =
      req.body;

    if (!registrationUuid) {
      registrationUuid = user.registrationUuid;
    }

    // Instantiate database
    const userRepository = config.db.user;

    // Fetch user's record
    const profile = await userRepository.findFirst({
      where: {
        registrationUuid,
      },
    });
    recordExists(profile);
    isDisabled(profile);

    if (email) {
      isValidEmail(email);
      profile!.emailConfirmed = false;
    }

    // Check if email already exists
    if (email) {
      const emailExists = await userRepository.findFirst({
        where: {
          email,
        },
      });
      if (emailExists && emailExists.registrationUuid !== registrationUuid) {
        return next(new AppError(messages.ERR_EMAIL_EXIST, 400));
      }
    }

    // Set user object properties
    profile!.email = email || profile!.email;
    profile!.phoneNumber = phoneNumber || profile!.phoneNumber;
    profile!.firstName = firstName || profile!.firstName;
    profile!.lastName = lastName || profile!.lastName;

    // Update user's record
    await userRepository.update({
      where: {
        registrationUuid: profile!.registrationUuid,
      },
      data: profile!,
    });

    // Create email verification token if changed
    if (email && email !== profile!.email) {
      profile!.emailConfirmed = false;
    }

    //  Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Operation successful.',
    });
  },
);
