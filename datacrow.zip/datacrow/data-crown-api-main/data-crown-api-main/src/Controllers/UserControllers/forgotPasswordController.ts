import config from '@/configs';
import { ITemp } from '@/configs/interface';
import catchAsync from '@/Helpers/catchAsync';
import { sendEmailNotification } from '@/Helpers/misc';
import { createToken } from '@/Helpers/util';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    const { email } = req.body;

    // Instantiate database
    const userRepository = config.db.user;
    const tempRepository = config.db.temp;

    // Fetch record
    const user = await userRepository.findFirst({
      where: {
        email,
      },
    });
    if (!user) {
      // Send response to client
      return res.status(200).json({
        status: 'success',
        message: 'Password reset email sent.',
        data: {
          email,
        },
      });
    }
    // isDisabled(user);

    const temp = await tempRepository.findFirst({
      where: {
        registrationUuid: user.registrationUuid,
        reason: 'FORGOT_PASSWORD',
      },
    });
    // Set token object properties
    const temp2: ITemp = {
      ...temp,
      registrationUuid: user.registrationUuid,
      tokenValue: createToken(),
      reason: 'FORGOT_PASSWORD',
      isUsed: false,
      createdAt: new Date(),
      expiredAt: new Date(
        new Date().setTime(new Date().getTime() + 30 * 60 * 1000),
      ).toISOString(),
    };

    await tempRepository.upsert({
      where: {
        id: temp2.id ?? 0,
      },
      create: temp2,
      update: temp2,
    });

    // Send email to user
    sendEmailNotification({
      message: `Click on the link below to reset your password: <br/> <a href="${config.app.frontendUrl}/reset-password/${temp2.tokenValue}`,
      registrationUuid: user.registrationUuid,
      subject: 'Recover Your Password',
    });

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Password reset email sent.',
      data: {
        email: user.email,
      },
    });
  },
);
