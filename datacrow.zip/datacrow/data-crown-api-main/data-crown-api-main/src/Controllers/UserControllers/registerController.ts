import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import {
  encryptData,
  sendEmailNotification,
} from '@/Helpers/misc';
import {
  generateOTP,
  generateReference,
  generateReferralCode,
  hasWhiteSpace,
  inputValidation,
  isValidEmail,
  removeSensitiveData,
} from '@/Helpers/util';
import config from '@/configs/index';
import { ITemp, IUser } from '@/configs/interface';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    let { email, password, phoneNumber } = req.body;

    const registrationUuid = generateReference();

    // Check if phone number was sent
    if (phoneNumber) {
      phoneNumber = inputValidation(phoneNumber);
    }

    hasWhiteSpace(email, 'Email');
    isValidEmail(email);

    // Instantiate database models
    const userRepository = config.db.user;
    const tempRepository = config.db.temp;

    // check if email exist
    const emailExists = await userRepository.findFirst({
      where: {
        email,
      },
    });
    if (emailExists) {
      return next(new AppError(messages.ERR_EMAIL_EXIST, 400));
    }

    // Check if phone number exists
    if (phoneNumber) {
      const phoneExists = await userRepository.findFirst({
        where: {
          phoneNumber,
        },
      });
      if (phoneExists) {
        return next(new AppError(messages.ERR_EXIST_PHONE, 400));
      }
    }

    // Hash user password
    password = encryptData(password, registrationUuid);

    // Set user object properties
    const user: IUser = {
      registrationUuid,
      password,
      email,
      balance: 0,
      referralCode: generateReferralCode(),
      createdAt: new Date().toISOString(),
    };

    // Save records to database
    const user1 = await userRepository.create({
      data: user as any,
    });

    // Set token object properties
    const temp: ITemp = {
      registrationUuid,
      tokenValue: generateOTP(4), // await createToken(),
      reason: 'EMAIL_VERIFICATION',
      isUsed: false,
      createdAt: new Date().toISOString(),
      expiredAt: new Date(
        new Date().setTime(new Date().getTime() + 30 * 60 * 1000),
      ).toISOString(),
    };

    await tempRepository.create({
      data: temp,
    });

    // Send account verification email
    sendEmailNotification({
      message: `Enter this OTP to verify your account: ${temp.tokenValue}`,
      registrationUuid,
      subject: 'Verify Your Email Address',
    });

    // Send response to client
    return res.status(201).json({
      status: 'success',
      message: 'Registration successful.',
      data: { ...removeSensitiveData(user1) },
    });
  },
);
