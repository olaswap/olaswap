import config from '@/configs';
import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import {
  isDisabled,
  jwtEncoder,
  recordExists,
  removeSensitiveData,
} from '@/Helpers/util';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    const { user, token } = req.body;

    // Initialize Token repository
    const tempRepository = config.db.temp;
    const userRepository = config.db.user;
    const walletRepository = config.db.wallet;

    // Fetch token
    const tokenData = await tempRepository.findFirst({
      where: {
        tokenValue: token,
        reason: 'EMAIL_VERIFICATION',
      },
    });
    if (!tokenData || tokenData.isUsed) {
      return next(new AppError(messages.ERR_INVALID_TOKEN, 400));
    }

    const profile = await userRepository.findFirst({
      where: {
        registrationUuid: tokenData.registrationUuid,
      },
    });
    // Fetch user's record
    if (user && !user.isAdmin) {
      recordExists(profile);
      isDisabled(profile);
    }

    // Check if account has been confirmed
    if (profile!.emailConfirmed) {
      return next(new AppError(messages.EMAIL_ALREADY_CONFIRMED, 400));
    }

    // Update users record
    profile!.emailConfirmed = true;
    tokenData.isUsed = true;
    await userRepository.update({
      where: {
        id: profile!.id,
      },
      data: profile!,
    });

    await tempRepository.update({
      where: {
        id: tokenData.id,
      },
      data: tokenData,
    });
    // Fetch account
    const account = await walletRepository.findFirst({
      where: {
        registrationUuid: profile!.registrationUuid,
      },
    });

    // Generate access token
    const accessToken = jwtEncoder({
      user: {
        registrationUuid: profile!.registrationUuid,
        isAdmin: false,
      },
    });

    return res.status(200).json({
      status: 'success',
      message: 'Email confirmed.',
      data: {
        account,
        user: removeSensitiveData(profile),
        ...accessToken,
      },
    });
  },
);
