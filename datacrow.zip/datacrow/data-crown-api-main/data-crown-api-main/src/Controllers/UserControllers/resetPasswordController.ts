import config from '@/configs';
import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import { encryptData, sendEmailNotification } from '@/Helpers/misc';
import { isDisabled, recordExists } from '@/Helpers/util';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    const { token, password } = req.body;

    // Instantiate database
    const userRepository = config.db.user;
    const tokenRepository = config.db.temp;

    // Check if token exists
    const tokenData = await tokenRepository.findFirst({
      where: {
        tokenValue: token,
        reason: 'FORGOT_PASSWORD',
      },
    });
    if (!tokenData || tokenData.isUsed) {
      return next(new AppError(messages.ERR_INVALID_TOKEN, 400));
    }

    // Fetch user's record
    const user = await userRepository.findFirst({
      where: {
        registrationUuid: tokenData.registrationUuid,
      },
    });
    recordExists(user);
    isDisabled(user);

    // Encrypt password
    const hashedPassword = encryptData(password, user!.registrationUuid);
    user!.password = hashedPassword;
    user!.createdAt = new Date();
    tokenData.isUsed = true;

    // Update password
    await userRepository.update({
      where: {
        registrationUuid: user!.registrationUuid,
      },
      data: user!,
    });

    // Mark token as used
    await tokenRepository.update({
      where: {
        id: tokenData.id,
      },
      data: tokenData,
    });

    // Send account verification email
    sendEmailNotification({
      registrationUuid: user!.registrationUuid,
      subject: 'Password Reset Successfully',
      message: 'Your password has been updated successfully.',
    });

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Password changed.',
    });
  },
);
