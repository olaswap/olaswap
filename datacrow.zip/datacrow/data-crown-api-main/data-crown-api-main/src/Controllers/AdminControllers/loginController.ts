import config from '@/configs';
import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import {
  comparePassword,
  jwtEncoder,
  removeSensitiveData,
} from '@/Helpers/util';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request | any, res: Response, next: NextFunction) => {
    const { email, password } = req.body;

    // Instantiate database repository
    const adminRepository = config.db.administrator;

    // Fetch profile
    const admin = await adminRepository.findFirst({
      where: {
        email,
      },
    });

    if (!admin) return next(new AppError(messages.ERR_LOGIN, 400));

    if (!admin.password) {
      return next(new AppError(messages.ERR_PASS_NOT_SET, 401));
    }

    const isCorrectPass = await comparePassword(
      password,
      admin.password as string,
      admin.registrationUuid,
    );
    if (!isCorrectPass) return next(new AppError(messages.ERR_LOGIN, 400));

    const accessToken = jwtEncoder({
      user: {
        registrationUuid: admin.registrationUuid,
        isAdmin: true,
      },
    });

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Authenticated.',
      data: {
        ...removeSensitiveData(admin),
        ...accessToken,
      },
    });
  },
);
