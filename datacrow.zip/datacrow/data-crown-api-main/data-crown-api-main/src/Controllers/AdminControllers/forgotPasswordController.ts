import catchAsync from '@/Helpers/catchAsync';
import { createToken, isRestricted } from '@/Helpers/util';
import { MailSender } from '@/Services/index';
import config from '@/configs';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    const { email } = req.body;

    // Instantiate database repository
    const adminRepository = config.db.administrator;
    const tempRepository = config.db.temp;

    // Fetch record
    const admin = await adminRepository.findFirst({
      where: {
        OR: [{ email }],
      },
    });
    if (!admin) {
      // Send response to client
      return res.status(200).json({
        status: 'success',
        message: 'Password reset email sent.',
        data: {
          email,
        },
      });
    }
    isRestricted(admin);

    const temp = await tempRepository.findFirst({
      where: {
        registrationUuid: admin.registrationUuid,
        reason: 'FORGOT_PASSWORD',
      },
    });
    // Set token object properties
    const token = {
      ...temp,
    };
    token.id = token?.id || undefined;
    token.registrationUuid = admin.registrationUuid;
    token.reason = 'FORGOT_PASSWORD';
    token.tokenValue = await createToken();
    token.isUsed = false;
    token.createdAt = new Date();
    token.expiredAt = new Date(new Date().getTime() + 30 * 60 * 1000);

    await tempRepository.upsert({
      where: {
        id: token.id ?? 0,
      },
      update: token,
      create: token as any,
    });

    // Send email to user
    new MailSender({ email }).sendMail({
      subject: 'Reset Password Instruction',
      message: token!.tokenValue,
    });

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Password reset email sent.',
      data: {
        email: admin!.email,
      },
    });
  },
);
