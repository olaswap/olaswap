import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import { encryptData } from '@/Helpers/misc';
import { isRestricted, recordExists } from '@/Helpers/util';
import { MailSender } from '@/Services/index';
import config from '@/configs';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    const { token, password } = req.body;
    // isStrongPassword(password);

    // Instantiate database repository
    const adminRepository = config.db.administrator;
    const tempRepository = config.db.temp;

    // Check if token exists
    const temp = await tempRepository.findFirst({
      where: {
        tokenValue: token,
        reason: 'FORGOT_PASSWORD',
      },
    });
    if (!temp || temp.isUsed) {
      return next(new AppError(messages.ERR_INVALID_TOKEN, 400));
    }

    // Fetch user's record
    const admin = await adminRepository.findFirst({
      where: {
        registrationUuid: temp.registrationUuid,
      },
    });
    recordExists(admin);
    isRestricted(admin);

    // Encrypt password
    const hashedPassword = encryptData(password, temp.registrationUuid);
    admin!.password = hashedPassword;
    admin!.updatedAt = new Date();
    temp.isUsed = true;

    // Update password
    await adminRepository.update({
      where: {
        registrationUuid: admin!.registrationUuid,
      },
      data: admin!,
    });

    // Mark token as used
    await tempRepository.upsert({
      where: {
        reason: 'FORGOT_PASSWORD',
        id: temp.id,
      },
      create: temp,
      update: temp,
    });

    // Send email to user
    new MailSender({ email: `${admin!.email}` }).sendMail({
      subject: 'Password Reset',
      message: 'Password reset successfully.',
    });

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Password changed.',
    });
  },
);
