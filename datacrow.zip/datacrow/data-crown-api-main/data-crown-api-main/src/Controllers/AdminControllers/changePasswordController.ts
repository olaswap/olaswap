import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import { encryptData } from '@/Helpers/misc';
import { comparePassword, isRestricted } from '@/Helpers/util';
import { MailSender } from '@/Services/index';
import config from '@/configs';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    let { registrationUuid, currentPassword, password, user } = req.body;

    if (!registrationUuid) {
      registrationUuid = user.registrationUuid;
    }

    // Instantiate database repository
    const adminRepository = config.db.administrator;

    // Fetch user's record
    const admin = await adminRepository.findFirst({
      where: { registrationUuid },
    });

    // Check user restriction
    isRestricted(admin);

    // Check if current password is correct
    const isCorrect = await comparePassword(
      currentPassword,
      admin!.password as string,
      admin!.registrationUuid,
    );
    if (!isCorrect) {
      return next(new AppError(messages.ERR_CUR_PASSWORD, 400));
    }

    // Encrypt new password
    admin!.password = encryptData(password, registrationUuid);
    admin!.updatedAt = new Date();

    // Update record
    await adminRepository.update({
      where: {
        registrationUuid,
      },
      data: admin!,
    });

    // Send email to user
    new MailSender({ email: `${admin?.email}` }).sendMail({
      subject: 'Password Changed',
      message: 'Password changed successfully.',
    });

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Password changed.',
    });
  },
);
