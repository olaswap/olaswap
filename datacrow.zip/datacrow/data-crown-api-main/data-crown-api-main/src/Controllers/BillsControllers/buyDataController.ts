import config from '@/configs';
import { networks } from '@/configs/constants';
import { TransactionTypes } from '@/configs/enums';
import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import { fetchUser, isValidNetwork } from '@/Helpers/misc';
import { generateReference, isValidPhoneNumber } from '@/Helpers/util';
import { HusmoData } from '@/Services';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    let { user, registrationUuid, phoneNumber, planId, plan, amount, network } =
      req.body;

    // isValidAmount(amount);
    isValidNetwork(network);
    phoneNumber = isValidPhoneNumber(phoneNumber);

    if (!registrationUuid) {
      registrationUuid = user.registrationUuid;
    }

    //   Fetch User
    const profile = await fetchUser(registrationUuid);
    if (profile!.balance!.lessThan(amount)) {
      return next(new AppError('Insufficient balance.', 400));
    }

    // Instantiate data villa
    const husmoData = new HusmoData();
    const networkId = networks.indexOf(network.toUpperCase()) + 1;

    // Buy airtime_type
    const resp = await husmoData.buyData(networkId, phoneNumber, planId);
    if (String(resp.Status).toLowerCase() !== 'successful') {
      return next(
        new AppError(resp.Message || 'Unable to complete request.', 400),
      );
    }

    // Save to history
    const tx = await config.db.history.create({
      data: {
        amount,
        registrationUuid,
        status: 'success',
        transactionReference: resp.indent || generateReference(),
        transactionType: TransactionTypes.debit,
        data: {
          amount: plan,
          id: resp.id,
          type: 'data',
          provider: network, phoneNumber,
        },
      },
    });

    // Debit user
    profile!.balance = profile!.balance!.minus(amount);
    await config.db.user.update({
      where: { registrationUuid },
      data: profile!,
    });

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Airtime purchased successfully.',
      data: tx,
    });
  },
);
