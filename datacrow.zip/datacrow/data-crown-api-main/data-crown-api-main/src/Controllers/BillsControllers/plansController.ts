import { INetworkPlans, IPlan } from '@/configs/interface';
import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import { HusmoData } from '@/Services';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    // let { user, registrationUuid } = req.body;

    // Instantiate data villa
    const husmoData = new HusmoData();

    // Buy airtime_type
    const resp = await husmoData.listPlans();
    if (!resp) {
      return next(new AppError('Unable to fetch plans.', 400));
    }

    const plans: INetworkPlans = {
      mtn: [],
      '9mobile': [],
      airtel: [],
      glo: [],
    };

    for (const item of resp.MTN_PLAN) {
      if (item.plan_type.toUpperCase() === 'DIRECT COUPON') {
        continue;
      }
      const plan: IPlan = {
        amount: Number(item.plan_amount) + Number(item.plan_amount) * 0.05,
        id: item.id,
        networkId: item.network,
        network: item.plan_network,
        validity: item.month_validate.replace(/--- /g, '').trim(),
        plan: item.plan,
        type: item.plan_type,
      };
      plans.mtn.push(plan);
    }

    for (const item of resp.GLO_PLAN) {
      const plan: IPlan = {
        amount: Number(item.plan_amount) + Number(item.plan_amount) * 0.05,
        id: item.id,
        networkId: item.network,
        network: item.plan_network,
        validity: item.month_validate.replace(/--- /g, '').trim(),
        plan: item.plan,
        type: item.plan_type,
      };
      plans.glo.push(plan);
    }

    for (const item of resp.AIRTEL_PLAN) {
      const plan: IPlan = {
        amount: Number(item.plan_amount) + Number(item.plan_amount) * 0.06,
        id: item.id,
        networkId: item.network,
        network: item.plan_network,
        validity: item.month_validate.replace(/--- /g, '').trim(),
        plan: item.plan,
        type: item.plan_type,
      };
      plans.airtel.push(plan);
    }

    for (const item of resp['9MOBILE_PLAN']) {
      const plan: IPlan = {
        amount: Number(item.plan_amount) + Number(item.plan_amount) * 0.06,
        id: item.id,
        networkId: item.network,
        network: item.plan_network,
        validity: item.month_validate.replace(/--- /g, '').trim(),
        plan: item.plan,
        type: item.plan_type,
      };
      plans['9mobile'].push(plan);
    }

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Plans fetched successfully.',
      data: plans,
    });
  },
);
