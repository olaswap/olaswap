import config from '@/configs';
import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import { isDisabled, isRestricted, recordExists } from '@/Helpers/util';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    let { user, registrationUuid, transactionReference }: any = {
      ...req.params,
      ...req.body,
      ...req.query,
    };
    if (!registrationUuid) registrationUuid = user.registrationUuid;

    // Instantiate database models
    const userRepository = config.db.user;
    const historyRepository = config.db.history;
    const adminRepository = config.db.administrator;

    if (!user.isAdmin) {
      // fetch user information
      const profile = await userRepository.findFirst({
        where: {
          registrationUuid,
        },
      });
      recordExists(profile, 'User');
      isDisabled(profile);
    } else {
      const profile = await adminRepository.findFirst({
        where: {
          registrationUuid,
        },
      });
      recordExists(profile, 'Account');
      isRestricted(profile);
    }

    // Fetch user transactions
    const tx: any = await historyRepository.findFirst({
      where: {
        transactionReference,
      },
    });

    recordExists(tx, 'Transactions');
    if (!user.isAdmin) {
      if (
        !Array.isArray(tx) &&
        tx!.registrationUuid &&
        tx!.registrationUuid !== registrationUuid
      ) {
        return next(new AppError('Transaction not found.', 404));
      }
    }

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Request completed.',
      data: tx,
    });
  },
);
