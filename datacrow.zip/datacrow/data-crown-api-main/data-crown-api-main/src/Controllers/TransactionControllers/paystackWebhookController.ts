import config from '@/configs';
import { TransactionTypes } from '@/configs/enums';
import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import { nairaSymbol } from '@/Helpers/misc';
import { Paystack } from '@/Services';
import { MailSender } from '@/Services/MailSender';
import crypto from 'crypto';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    const { data, event } = req.body;

    const hash = crypto
      .createHmac('sha512', config.paystack.secretKey)
      .update(JSON.stringify(req.body))
      .digest('hex');
    if (hash !== req.headers['x-paystack-signature']) {
      return next(new AppError('Invalid signature.', 400));
    }

    // Check event
    if (String(event).toUpperCase() !== 'CHARGE.SUCCESS') {
      return next(new AppError('Invalid event.', 400));
    }

    // Instantiate Paystack API
    const paystackService = new Paystack();
    // Check transaction status
    const paystackResponse = await paystackService.verifyTransaction(
      data.reference,
    );
    if (!paystackResponse.status) {
      return next(new AppError(paystackResponse.message, 400));
    }
    const paystackResponseData = paystackResponse.data;
    const amount: number = Number(paystackResponseData.amount / 100);
    const fee: number = Number(paystackResponseData.fees) / 100;

    const userRepository = config.db.user;
    const transactionRepository = config.db.history;
    // Fetch transaction
    const tx = await transactionRepository.findFirst({
      where: {
        transactionReference: paystackResponseData.reference,
      },
    });
    if (tx && tx.status !== 'pending') {
      return next(new AppError('Transaction already completed.', 200));
    }

    const profile = await userRepository.findFirst({
      where: {
        OR: [
          { registrationUuid: tx!.registrationUuid },
          { email: (tx!.data as any).email },
        ],
      },
    });

    // Save transaction
    tx!.status =
      String(paystackResponseData.status).toUpperCase() === 'SUCCESS'
        ? 'success'
        : 'failed';
    tx!.amount = amount as any;
    tx!.registrationUuid = profile!.registrationUuid;
    tx!.createdAt =
      tx!.createdAt ?? new Date(paystackResponseData.created_at).toISOString();
    tx!.updatedAt = new Date(paystackResponseData.paid_at);
    tx!.transactionType = TransactionTypes.credit;
    tx!.transactionReference = paystackResponseData.reference;
    tx!.data = {
      ...(tx!.data as any),
      firstName: paystackResponseData.customer.first_name,
      lastName: paystackResponseData.customer.last_name,
      email: (tx!.data as any).email ? (tx!.data as any).email : paystackResponseData.customer.email,
      phoneNumber: paystackResponseData.customer.phone,
    };
    await transactionRepository.upsert({
      where: {
        transactionReference: tx!.transactionReference,
      },
      create: tx! as any,
      update: tx! as any,
    });

    const amountToCredit = amount - fee - (amount * 0.014);
    if (profile) {
      profile.balance = profile!
        .balance!.plus(amountToCredit);
      await userRepository.update({
        where: {
          registrationUuid: profile.registrationUuid,
        },
        data: profile,
      });

      // Send email to client
      new MailSender({
        email: profile.email,
        username: profile.firstName || 'User',
      }).sendMail({
        subject: 'FUND RECEIVED',
        message: `Your account was credited with the Sum of ${nairaSymbol}${amountToCredit}. Thank you,` ,
      });
    }

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Transaction completed.',
    });
  },
);
