import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import messages from '@/Helpers/messages';
import { recordExists } from '@/Helpers/util';
import config from '@/configs';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    const { user }: any = {
      ...req.params,
      ...req.body,
      ...req.query,
    };

    if (!user.isAdmin) {
      return next(new AppError(messages.ERR_OPERATION_NOT_ALLOWED, 401));
    }

    // Instantiate database models
    const historyRepository = config.db.history;

    const txs = await historyRepository.findMany({
      orderBy: {
        createdAt: 'desc',
      },
    });
    recordExists(txs, 'Transactions');

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Request completed.',
      data: txs,
    });
  },
);
