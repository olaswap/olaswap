import catchAsync from '@/Helpers/catchAsync';
import { isDisabled, recordExists } from '@/Helpers/util';
import config from '@/configs';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(
  async (req: Request, res: Response, next: NextFunction) => {
    let { user, registrationUuid }: any = {
      ...req.params,
      ...req.body,
      ...req.query,
    };
    if (!registrationUuid) registrationUuid = user.registrationUuid;

    // Instantiate database models
    const userRepository = config.db.user;
    const historyRepository = config.db.history;

    // fetch user information
    const profile = await userRepository.findFirst({
      where: {
        registrationUuid,
      },
    });
    recordExists(profile, 'User');
    isDisabled(profile);

    // Fetch user transactions
    const txs = await historyRepository.findMany({
      orderBy: {
        createdAt: 'desc',
      },
      where: {
        registrationUuid,
      },
    });
    recordExists(txs, 'Transactions');

    // Send response to client
    return res.status(200).json({
      status: 'success',
      message: 'Request completed.',
      data: txs,
    });
  },
);
