import AppError from '@/Helpers/AppError';
import catchAsync from '@/Helpers/catchAsync';
import { isValidAmount } from '@/Helpers/misc';
import { isLocked, recordExists } from '@/Helpers/util';
import { Paystack } from '@/Services';
import config from '@/configs';
import { TransactionTypes } from '@/configs/enums';
import { IHistory } from '@/configs/interface';
import { NextFunction, Request, Response } from 'express';

export default catchAsync(async function (
  req: Request,
  res: Response,
  next: NextFunction,
) {
  let { user, registrationUuid, amount } = req.body;
  if (!registrationUuid) registrationUuid = user.registrationUuid;
  isValidAmount(amount);

  // Instantiate database models
  const historyRepository = config.db.history;
  const userRepository = config.db.user;

  // Fetch user's record
  const profile = await userRepository.findFirst({
    where: {
      registrationUuid,
    },
  });
  recordExists(profile);
  isLocked(profile);

  // Check if transaction already exists
  const txs = await historyRepository.findMany({
    where: {
      AND: [{ registrationUuid }, { status: 'pending' }, { amount }],
    },
  });

  // Send response to client
  if (txs.length > 0) {
    return res.status(201).json({
      status: 'success',
      message: 'Payment details.',
      data: { ...txs[0] },
    });
  }

  // Initialize Paystack API
  const paystackService = new Paystack();

  // Initialize payment
  const paystackResponse = await paystackService.initializePayment(
    profile!.email,
    amount,
  );
  if (!paystackResponse.status) {
    return next(new AppError(paystackResponse.message, 400));
  }

  // Save transaction
  const tx: IHistory = {
    transactionReference: paystackResponse.data.reference,
    registrationUuid: profile!.registrationUuid,
    transactionType: TransactionTypes.credit,
    amount,
    data: {
      type: 'credit',
      accessCode: paystackResponse.data.access_code,
      reference: paystackResponse.data.reference,
      amount,
      url: paystackResponse.data.authorization_url,
    },
    status: 'pending',
    createdAt: new Date(),
  };

  await historyRepository.create({
    data: tx as any,
  });

  // Send response to client
  return res.status(201).json({
    status: 'success',
    message: 'Payment details.',
    data: { ...tx },
  });
});
