import config from '@/configs';
import AppError from '@/Helpers/AppError';
import axios from 'axios';

export class HusmoData {
  private apiKey: string = config.husmoData.apiKey;
  private baseUrl: string = config.husmoData.baseUrl;

  private getHeader() {
    return {
      'Content-Type': 'application/json',
      Authorization: `Token ${this.apiKey}`,
    };
  }

  public async buyData(network: number, phoneNumber: string, planId: number) {
    const res = await axios({
      method: 'POST',
      url: `${this.baseUrl}/api/data/`,
      data: {
        network,
        mobile_number: phoneNumber,
        Ported_number: true,
        plan: planId,
      },
      headers: this.getHeader(),
    }).catch(this.errorHandler);

    if (!res!.data) {
      throw new AppError(res!.data.message, 400);
    }

    return res!.data;
  }

  public async buyAirtime(
    network: number,
    amount: number,
    phoneNumber: string,
  ) {
    const res = await axios({
      method: 'POST',
      url: `${this.baseUrl}/api/topup/`,
      data: {
        network,
        amount,
        Ported_number: true,
        mobile_number: phoneNumber,
        airtime_type: 'VTU',
      },
      headers: this.getHeader(),
    }).catch(this.errorHandler);

    if (!res!.data) {
      throw new AppError(res!.data.message, 400);
    }

    return res!.data;
  }

  public async listPlans() {
    const res = await axios({
      url: `${this.baseUrl}/api/network`,
      method: 'GET',
      headers: this.getHeader(),
    }).catch(this.errorHandler);
    if (!res!.data) {
      throw new AppError(res!.data.message, 400);
    }

    return res!.data;
  }

  public async payBill(disco: string, meterNumber: string, meterType: string) {
    const res = await axios({
      method: 'POST',
      url: `${this.baseUrl}/api/billpayment/`,
      data: {
        disco_name: disco,
        meter_number: meterNumber,
        MeterType: meterType,
      },
      headers: this.getHeader(),
    }).catch(this.errorHandler);
    if (!res!.data) {
      throw new AppError(res!.data.message, 400);
    }

    return res!.data;
  }

  public async payCable(
    cableName: string,
    cablePlan: string,
    smartCardNumber: string,
  ) {
    const res = await axios({
      method: 'POST',
      url: `${this.baseUrl}/api/cablesub`,
      data: {
        cablename: cableName,
        cableplan: cablePlan,
        smart_card_number: smartCardNumber,
      },
      headers: this.getHeader(),
    }).catch(this.errorHandler);
    if (!res!.data) {
      throw new AppError(res!.data.message, 400);
    }

    return res!.data;
  }

  /**
   *
   * @param {any} error
   */
  private errorHandler(error: any) {
    if (axios.isAxiosError(error)) {
      // eslint-disable-next-line no-self-assign
      error = error;
      if (error.response && error.response!.data) {
        for (const key in error.response.data) {
          if (Object.prototype.hasOwnProperty.call(error.response.data, key)) {
            const element = error.response.data[key];
            if (Array.isArray(element)) {
              error.message = element[0];
            } else {
              error.message = element;
            }
            break;
          }
        }
        throw new AppError(error.message, error.response?.status || 400);
      }
      if (error.response?.data.message) {
        throw new AppError(
          error.response?.data.message || error.message,
          error.response?.status,
        );
      }
    } else {
      throw new AppError('Unexpected error occurred.', 500);
    }
  }
}
