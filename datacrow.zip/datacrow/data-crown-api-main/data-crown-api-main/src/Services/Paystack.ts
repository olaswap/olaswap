import axios from 'axios';

import config from '@/configs';
import AppError from '@/Helpers/AppError';

/**
 * @classdesc This will expose Paystack API interface
 * @class Paystack
 * @author Raphael Okunlola<raphael.okunlola@deebezt.com>
 *
 */
export class Paystack {
  private baseUrl: string;

  constructor() {
    axios.defaults.baseURL = config.paystack.baseUrl;
    this.baseUrl = config.paystack.baseUrl;
  }

  /**
   *@private
   * @return {object}
   */
  private header(): any {
    return {
      Authorization: `Bearer ${config.paystack.secretKey}`,
      'Content-Type': 'application/json',
    };
  }

  public async fetchBanks() {
    const res = await axios({
      method: 'GET',
      url: `${this.baseUrl}/bank?country=Nigeria`,
      headers: this.header(),
    }).catch(this.errorHandler);
    if (!res!.data || !res!.data.status) {
      throw new AppError(res!.data.message, 400);
    }

    return res!.data;
  }

  public async validateAccount(accountNumber: string, bankCode: string) {
    const res = await axios({
      method: 'GET',
      url: `${this.baseUrl}/bank/resolve?account_number=${accountNumber}&bank_code=${bankCode}`,
      headers: this.header(),
    }).catch(this.errorHandler);

    if (!res!.data || !res!.data.status) {
      throw new AppError(res!.data.message, 400);
    }

    return res!.data;
  }

  public async createRecipient(
    accountNumber: string,
    accountName: string,
    bankCode: string,
  ) {
    const res = await axios({
      method: 'POST',
      data: {
        name: accountName,
        account_number: accountNumber,
        bank_code: bankCode,
        currency: 'NGN',
        type: 'nuban',
      },
      url: `${this.baseUrl}/transferrecipient`,
      headers: this.header(),
    }).catch(this.errorHandler);

    if (!res!.data || !res!.data.status) {
      throw new AppError(res!.data.message, 400);
    }

    return res!.data;
  }

  public async transferFund(
    transactionReference: string,
    recipient: string,
    amount: number,
    desc?: string,
  ) {
    const res = await axios({
      method: 'POST',
      data: {
        recipient,
        reference: transactionReference,
        amount: amount * 100,
        source: 'balance',
        reason: desc,
      },
      url: `${this.baseUrl}/transfer`,
      headers: this.header(),
    }).catch(this.errorHandler);

    if (!res!.data || !res!.data.status) {
      throw new AppError(res!.data.message, 400);
    }

    return res!.data;
  }

  /**
   * Initialize payment
   * @param {string} email - Customer's email address
   * @param {number} amount - Amount to pay
   * @param {string} callbackURL
   * @return {object}
   */
  public async initializePayment(
    email: string,
    amount: number,
    callbackURL: string = config.paystack.callbackUrl,
  ): Promise<any> {
    const res = await axios({
      method: 'POST',
      url: `${this.baseUrl}/transaction/initialize`,
      data: {
        email,
        amount: Number(amount) * 100,
        callback_url: callbackURL,
        channels: [
          'card',
          'bank',
          'ussd',
          'qr',
          'mobile_money',
          'bank_transfer',
        ],
      },
      headers: this.header(),
    }).catch(this.errorHandler);

    return res?.data;
  }

  /**
   * Check transaction status by fetching transaction details
   * @param {string} transactionReference - Transaction reference
   * @return {any}
   */
  public async verifyTransaction(transactionReference: string): Promise<any> {
    const res = await axios({
      method: 'GET',
      url: `${this.baseUrl}/transaction/verify/${transactionReference}`,
      headers: this.header(),
    }).catch(this.errorHandler);

    return res?.data;
  }

  /**
   * Fetch transactions history
   * @return {any}
   */
  public async fetchTransactions(): Promise<any> {
    const res = await axios({
      method: 'GET',
      url: `${this.baseUrl}/transaction/`,
      headers: this.header(),
    }).catch(this.errorHandler);

    return res?.data;
  }

  /**
   * Fetch single transaction
   * @param {number} transactionId
   * @return {any}
   */
  public async fetchTransaction(transactionId: number): Promise<any> {
    const res = await axios({
      method: 'GET',
      url: `${this.baseUrl}/transaction/${transactionId}`,
      headers: this.header(),
    }).catch(this.errorHandler);

    return res?.data;
  }

  /**
   *
   * @param {any} error
   */
  private errorHandler(error: any) {
    if (axios.isAxiosError(error)) {
      // eslint-disable-next-line no-self-assign
      error = error;
      throw new AppError(
        error.response?.data.message || error.message,
        error.response?.status,
      );
    } else {
      throw new AppError('Unexpected error occurred.', 500);
    }
  }
}
