-- CreateTable
CREATE TABLE `users` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `registrationUuid` VARCHAR(100) NOT NULL,
    `firstName` VARCHAR(100) NULL,
    `lastName` VARCHAR(100) NULL,
    `email` VARCHAR(255) NOT NULL,
    `phoneNumber` VARCHAR(50) NULL,
    `password` TEXT NULL,
    `emailConfirmed` BOOLEAN NOT NULL DEFAULT false,
    `referralCode` VARCHAR(20) NOT NULL,
    `balance` DECIMAL(10, 2) NULL DEFAULT 0.00,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NULL,

    UNIQUE INDEX `users_registrationUuid_key`(`registrationUuid`),
    UNIQUE INDEX `users_id_registrationUuid_key`(`id`, `registrationUuid`),
    FULLTEXT INDEX `users_registrationUuid_idx`(`registrationUuid`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `wallets` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `walletUuid` VARCHAR(100) NOT NULL,
    `registrationUuid` VARCHAR(100) NOT NULL,
    `accountNumber` VARCHAR(10) NOT NULL,
    `accountName` VARCHAR(200) NOT NULL,
    `bankName` VARCHAR(255) NOT NULL,
    `bankCode` VARCHAR(20) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NULL,

    UNIQUE INDEX `wallets_walletUuid_key`(`walletUuid`),
    UNIQUE INDEX `wallets_registrationUuid_key`(`registrationUuid`),
    FULLTEXT INDEX `wallets_registrationUuid_idx`(`registrationUuid`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `administrators` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `registrationUuid` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) NOT NULL,
    `password` TEXT NOT NULL,
    `createdAt` DATETIME(3) NOT NULL,
    `updatedAt` DATETIME(3) NULL,

    UNIQUE INDEX `administrators_registrationUuid_key`(`registrationUuid`),
    UNIQUE INDEX `administrators_id_registrationUuid_key`(`id`, `registrationUuid`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `histories` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `transactionReference` VARCHAR(100) NOT NULL,
    `registrationUuid` VARCHAR(100) NOT NULL,
    `transactionType` ENUM('credit', 'debit') NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    `data` JSON NOT NULL,
    `status` ENUM('pending', 'success', 'failed') NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NULL,

    UNIQUE INDEX `histories_transactionReference_key`(`transactionReference`),
    UNIQUE INDEX `histories_id_transactionReference_key`(`id`, `transactionReference`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `temps` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `registrationUuid` VARCHAR(255) NOT NULL,
    `tokenValue` VARCHAR(100) NOT NULL,
    `reason` ENUM('EMAIL_VERIFICATION', 'FORGOT_PASSWORD') NOT NULL,
    `isUsed` BOOLEAN NOT NULL DEFAULT true,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `expiredAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `temps_id_key`(`id`),
    FULLTEXT INDEX `temps_tokenValue_idx`(`tokenValue`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `wallets` ADD CONSTRAINT `wallets_registrationUuid_fkey` FOREIGN KEY (`registrationUuid`) REFERENCES `users`(`registrationUuid`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `histories` ADD CONSTRAINT `histories_registrationUuid_fkey` FOREIGN KEY (`registrationUuid`) REFERENCES `users`(`registrationUuid`) ON DELETE RESTRICT ON UPDATE CASCADE;
