/* eslint-disable no-console */
import { createDefaultAdmin } from './data/admin';

createDefaultAdmin().then(() => {
  console.info('Default admin created ✅');
}).catch(console.log);
