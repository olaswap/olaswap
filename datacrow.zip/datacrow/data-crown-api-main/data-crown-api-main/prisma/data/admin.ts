import { PrismaClient } from '@prisma/client';
import { v4 } from 'uuid';
import { encryptData } from '../../src/Helpers/misc';

export async function createDefaultAdmin() {
  const prisma: PrismaClient = new PrismaClient();
  prisma.$connect();
  let admin = await prisma.administrator.findFirst({
    where: {
      id: 1,
    },
  });
  if (!admin) {
    const registrationUuid = v4();
    const encryptedPassword = encryptData(
      `DataCrown@${new Date().getFullYear()}`,
      registrationUuid,
    );
    admin = await prisma.administrator.create({
      data: {
        email: 'olaleyeidris27@gmail.com',
        password: encryptedPassword,
        registrationUuid,
        createdAt: new Date().toISOString(),
      },
    });
  }
  await prisma.$disconnect();

  return admin;
}
